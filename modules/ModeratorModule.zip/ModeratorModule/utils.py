#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html


from mautrix.types import UserID, RoomID
from mxc import utils


async def resolve_user(mx, event, target: str | None = None) -> str | None:
    replied = await utils.get_reply_event(mx, event)
    if replied:
        return replied.sender
    if target and target.startswith("@"):
        return target
    return None


async def get_pl(mx, room_id: RoomID):
    return await utils.get_power_levels(mx, room_id)


async def get_user_pl(mx, room_id: RoomID, user_id: UserID) -> int:
    pl = await get_pl(mx, room_id)
    if not pl:
        return 0
    return pl.users.get(user_id, pl.users_default)


async def can_act(mx, room_id: RoomID, user_id: UserID, required_level: int) -> bool:
    pl = await get_pl(mx, room_id)
    if not pl:
        return False
    return pl.users.get(user_id, pl.users_default) >= required_level


async def is_owner_in_room(mx, room_id: RoomID, user_id: UserID) -> bool:
    pl = await get_pl(mx, room_id)
    if not pl:
        return False
    return pl.users.get(user_id, pl.users_default) >= 100

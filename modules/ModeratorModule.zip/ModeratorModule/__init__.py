#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html


import asyncio
import re

from mautrix.types import EventType, Membership, MessageEvent, StateEvent

from ... import loader
from mxc import utils as mxc_utils

from .utils import can_act, resolve_user


class Meta:
    name = "Moderator"
    description = "Admin tools, moderation, notes, pins, and CAPTCHA"
    version = "1.1.0"
    tags = ["admin", "moderation", "utility"]


@loader.tds(collect="/modules")
class ModeratorModule(loader.Module):
    strings = {
        "no_perm": "<b>⚠️ | Недостаточно прав</b>",
        "no_user": "<b>⚠️ | Укажите пользователя или ответьте на сообщение</b>",
        "reply_required": "<b>⚠️ | Ответьте на сообщение</b>",
        "promoted": "<b>✅ | {user} повышен до уровня {level}</b>",
        "demoted": "<b>✅ | {user} понижен</b>",
        "adminlist_title": "<b>📋 Админы комнаты:</b><br>{}",
        "admincache": "<b>✅ | Кэш админов обновлён</b>",
        "banned": "<b>🔨 | {user} забанен</b>{}",
        "unbanned": "<b>✅ | {user} разбанен</b>",
        "kicked": "<b>👢 | {user} кикнут</b>{}",

        "redacted": "<b>✅ | Сообщение удалено</b>",
        "pinned": "<b>📌 | Сообщение закреплено</b>",
        "unpinned": "<b>✅ | Закрепление снято</b>",
        "no_pinned": "<b>📌 | Нет закреплённых сообщений</b>",
        "pinned_msg": "<b>📌 Закреплено:</b><br>{}",
        "note_exists": "<b>⚠️ | Заметка <code>{name}</code> уже существует</b>",
        "note_saved": "<b>✅ | Заметка <code>{name}</code> сохранена</b>",
        "note_deleted": "<b>✅ | Заметка <code>{name}</code> удалена</b>",
        "note_not_found": "<b>⚠️ | Заметка <code>{name}</code> не найдена</b>",
        "notes_empty": "<b>📝 | В этой комнате нет заметок</b>",
        "notes_list": "<b>📝 Заметки:</b><br>{}",
        "notes_cleared": "<b>✅ | Все заметки удалены</b>",
        "note_usage_add": "<b>⚠️ | Использование:</b> <code>note add &lt;название&gt; [текст]</code> (или ответь на сообщение)",
        "note_usage_remove": "<b>⚠️ | Использование:</b> <code>note remove &lt;название&gt;</code>",
        "note_usage_get": "<b>⚠️ | Использование:</b> <code>note get &lt;название&gt;</code>",
        "note_usage": "<b>⚠️ | Использование:</b> <code>note add/remove/get/list &lt;название&gt;</code>",
        "captcha_prompt": "<b>🤖 | Докажи что ты человек! Отправь: {emoji}</b>",
        "captcha_passed": "<b>✅ | Капча пройдена! Добро пожаловать!</b>",
        "captcha_on": "<b>✅ | Капча включена для этой комнаты</b>",
        "captcha_off": "<b>✅ | Капча выключена для этой комнаты</b>",
        "captcha_timeout_set": "<b>✅ | Таймаут капчи установлен: {t}с</b>",
        "group_added": "<b>✅ | Комната добавлена в список</b>",
        "group_removed": "<b>✅ | Комната удалена из списка</b>",
        "groups_list": "<b>📋 Подключённые комнаты:</b><br>{}",
        "no_groups": "<b>📋 | Нет подключённых комнат</b>",
        "group_required": "<b>⚠️ | Комната не подключена. Сначала: <code>addgroup</code></b>",
        "welcome_on": "<b>✅ | Приветствие включено</b>",
        "welcome_off": "<b>✅ | Приветствие выключено</b>",
        "welcome_set": "<b>✅ | Текст приветствия сохранён</b>",
        "welcome_get": "<b>👋 Приветствие:</b><br>Статус: {status}<br><br>{text}{media}",
        "welcome_usage": "<b>⚠️ | Использование:</b> <code>welcome on/off/set/get</code>",
        "welcome_usage_set": "<b>⚠️ | Использование:</b> <code>welcome set &lt;текст&gt;</code> (или ответь на сообщение с медиа)",
        "goodbye_on": "<b>✅ | Прощание включено</b>",
        "goodbye_off": "<b>✅ | Прощание выключено</b>",
        "goodbye_set": "<b>✅ | Текст прощания сохранён</b>",
        "goodbye_get": "<b>👋 Прощание:</b><br>Статус: {status}<br><br>{text}{media}",
        "goodbye_usage": "<b>⚠️ | Использование:</b> <code>goodbye on/off/set/get</code>",
        "goodbye_usage_set": "<b>⚠️ | Использование:</b> <code>goodbye set &lt;текст&gt;</code> (или ответь на сообщение с медиа)",
    }

    config = {
        "default_promote_level": loader.ConfigValue(50, "Default power level for promote"),
    }

    _IMG_TAG_RE = re.compile(r"<img=([a-z0-9+.-]+://[^>]+)>", re.IGNORECASE)

    async def _matrix_start(self, mx):
        self._captcha_pending = {}
        self._captcha_original_pl = {}
        self._pending_welcome = {}

    async def check_group(self, mx, event) -> bool:
        groups = await self._get("mod_groups", [])
        if event.room_id not in groups:
            await mxc_utils.answer(mx, self.strings["group_required"])
            return False
        return True

    async def check_admin(self, mx, event, level: int = 50) -> str | None:
        ok = await can_act(mx, event.room_id, event.sender, level)
        if not ok:
            await mxc_utils.answer(mx, self.strings["no_perm"])
            return None
        return event.sender

    async def get_target(self, mx, event, user: str | None = None) -> str | None:
        target = await resolve_user(mx, event, user)
        if not target:
            await mxc_utils.answer(mx, self.strings["no_user"])
        return target

    async def _resolve_tags(self, mx, user_id: str, text: str) -> str:
        display_name = user_id.split(":")[0].lstrip("@")
        try:
            profile = await mx.client.get_profile(user_id)
            dn = profile.get("displayname", "") or ""
            if dn:
                display_name = dn
        except Exception:
            pass
        localpart = user_id.split(":")[0].lstrip("@")
        server = user_id.split(":", 1)[1] if ":" in user_id else ""
        mention = f'<a href="https://matrix.to/#/{user_id}">{display_name}</a>'
        text = text.replace("{mention}", mention)
        text = text.replace("{name}", display_name)
        text = text.replace("{surname}", server)
        text = text.replace("{username}", localpart)
        return text

    async def _send_welcome(self, mx, room_id: str, user_id: str):
        enabled = await self._get(f"welcome_enabled_{room_id}", False)
        if not enabled:
            return
        text = await self._get(f"welcome_text_{room_id}", "")
        media = await self._get(f"welcome_media_{room_id}", "")
        mime = await self._get(f"welcome_mime_{room_id}", "image/png")
        text = await self._resolve_tags(mx, user_id, text)
        await self._parse_and_send(mx, room_id, text, media, mime)

    async def _send_goodbye(self, mx, room_id: str, user_id: str):
        enabled = await self._get(f"goodbye_enabled_{room_id}", False)
        if not enabled:
            return
        text = await self._get(f"goodbye_text_{room_id}", "")
        media = await self._get(f"goodbye_media_{room_id}", "")
        mime = await self._get(f"goodbye_mime_{room_id}", "image/png")
        text = await self._resolve_tags(mx, user_id, text)
        await self._parse_and_send(mx, room_id, text, media, mime)

    async def _parse_and_send(self, mx, room_id: str, text: str, media_url: str, mime: str):
        from mxc.types.media import Image as MXImage

        match = self._IMG_TAG_RE.search(text)
        if match:
            url = match.group(1)
            text = (text[:match.start()] + text[match.end():]).strip()
            if url:
                media_url = url
        if media_url:
            await mxc_utils.answer(mx, text=text or None, media=MXImage(url=media_url, mimetype=mime), room_id=room_id)
        elif text:
            await mxc_utils.answer(mx, text, room_id=room_id)

    @loader.on(EventType.ROOM_MEMBER)
    async def member_handler(self, mx, event: StateEvent):
        if event.type != EventType.ROOM_MEMBER:
            return

        if event.content.membership == Membership.JOIN:
            if event.state_key == mx.client.mxid:
                return
            from .modules.captcha import handle_join, _get_captcha_conf
            await handle_join(mx, event, self)
            conf = await _get_captcha_conf(self, event.room_id)
            if conf.get("enabled"):
                self._pending_welcome[event.state_key] = event.room_id
            else:
                await self._send_welcome(mx, event.room_id, event.state_key)

        elif event.content.membership == Membership.LEAVE and event.state_key != mx.client.mxid:
            await self._send_goodbye(mx, event.room_id, event.state_key)

    @loader.on(EventType.ROOM_MESSAGE)
    async def message_handler(self, mx, event: MessageEvent):
        from .modules.captcha import check_message
        passed = await check_message(mx, event, self)
        if passed:
            user_id = event.sender
            room_id = self._pending_welcome.pop(user_id, None)
            if room_id:
                await self._send_welcome(mx, room_id, user_id)


__all__ = ["ModeratorModule"]
#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

from .. import loader
from .. import ModeratorModule
from mxc import utils


class AdminCommands(ModeratorModule):
    @loader.command()
    async def promote(self, mx, event, level: int | None = None, user: str = None):
        """[user] [level=50] — повысить пользователя"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        target = await self.get_target(mx, event, user)
        if not target:
            return

        if level is None:
            level = self.config["default_promote_level"]

        if not await utils.set_power_level(mx, event.room_id, target, level):
            await utils.answer(mx, self.strings["no_perm"])
            return
        await utils.answer(mx, self.strings["promoted"].format(user=target, level=level))

    @loader.command()
    async def demote(self, mx, event, user: str = None):
        """[user] — понизить пользователя"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        target = await self.get_target(mx, event, user)
        if not target:
            return

        pl = await utils.get_power_levels(mx, event.room_id)
        if not pl:
            await utils.answer(mx, "<b>⚠️ | Не удалось получить PL</b>")
            return
        default_level = pl.users_default
        if not await utils.set_power_level(mx, event.room_id, target, default_level):
            await utils.answer(mx, self.strings["no_perm"])
            return
        await utils.answer(mx, self.strings["demoted"].format(user=target))

    @loader.command()
    async def adminlist(self, mx, event):
        """Список админов комнаты"""
        if not await self.check_group(mx, event):
            return
        room = await utils.get_room(mx, event.room_id)
        if not room or not room.get("power_levels"):
            await utils.answer(mx, "<b>⚠️ | Не удалось получить информацию о комнате</b>")
            return

        pl = room["power_levels"]
        out = [
            f"  <code>{uid}</code> — level {pl.users.get(uid, pl.users_default)}"
            for uid in room["admins"]
        ]
        await utils.answer(
            mx,
            self.strings["adminlist_title"].format(
                "<br>".join(sorted(out)) or "  <i>Нет админов</i>"
            ),
        )

    @loader.command()
    async def admincache(self, mx, event):
        """Принудительно обновить кэш админов"""
        if not await self.check_group(mx, event):
            return
        pl = await utils.get_power_levels(mx, event.room_id)
        if pl is None:
            await utils.answer(mx, "<b>⚠️ | У бота нет прав</b>")
            return
        await utils.answer(mx, self.strings["admincache"])

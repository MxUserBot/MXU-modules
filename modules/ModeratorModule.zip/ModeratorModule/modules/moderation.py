#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

from .. import loader
from .. import ModeratorModule
from mxc import utils


class ModerationCommands(ModeratorModule):
    @loader.command()
    async def ban(self, mx, event, user: str = None, reason: str = ""):
        """[user] [reason] — забанить пользователя"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        target = await self.get_target(mx, event, user)
        if not target:
            return
        await mx.client.ban_user(event.room_id, target, reason)
        r = f"<br>Причина: <code>{reason}</code>" if reason else ""
        await utils.answer(mx, self.strings["banned"].format(user=target, reason=r))

    @loader.command()
    async def unban(self, mx, event, user: str = None):
        """[user] — разбанить пользователя"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        target = await self.get_target(mx, event, user)
        if not target:
            return
        await mx.client.unban_user(event.room_id, target)
        await utils.answer(mx, self.strings["unbanned"].format(user=target))

    @loader.command()
    async def kick(self, mx, event, user: str = None, reason: str = ""):
        """[user] [reason] — кикнуть пользователя"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        target = await self.get_target(mx, event, user)
        if not target:
            return
        await mx.client.kick_user(event.room_id, target, reason)
        r = f"<br>Причина: <code>{reason}</code>" if reason else ""
        await utils.answer(mx, self.strings["kicked"].format(user=target, reason=r))

    @loader.command()
    async def dban(self, mx, event, reason: str = ""):
        """[reason] — забанить по реплаю + удалить сообщение"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        if not replied:
            await utils.answer(mx, self.strings["reply_required"])
            return
        await mx.client.ban_user(event.room_id, replied.sender, reason)
        try:
            await mx.client.redact(event.room_id, replied.event_id, reason)
        except Exception:
            pass
        r = f"<br>Причина: <code>{reason}</code>" if reason else ""
        await utils.answer(mx, self.strings["banned"].format(user=replied.sender, reason=r))

    @loader.command()
    async def dkick(self, mx, event, reason: str = ""):
        """[reason] — кикнуть по реплаю + удалить сообщение"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        if not replied:
            await utils.answer(mx, self.strings["reply_required"])
            return
        await mx.client.kick_user(event.room_id, replied.sender, reason)
        try:
            await mx.client.redact(event.room_id, replied.event_id, reason)
        except Exception:
            pass
        r = f"<br>Причина: <code>{reason}</code>" if reason else ""
        await utils.answer(mx, self.strings["kicked"].format(user=replied.sender, reason=r))

    @loader.command()
    async def redact(self, mx, event, reason: str = ""):
        """[reason] — удалить сообщение (по реплаю)"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        if not replied:
            await utils.answer(mx, self.strings["reply_required"])
            return
        await mx.client.redact(event.room_id, replied.event_id, reason)
        await utils.answer(mx, self.strings["redacted"])

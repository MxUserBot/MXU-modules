#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

from mautrix.types import EventType

from .. import loader
from .. import ModeratorModule
from mxc import utils


class PinCommands(ModeratorModule):
    @loader.command()
    async def pin(self, mx, event):
        """Ответь на сообщение чтобы закрепить его"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        if not replied:
            await utils.answer(mx, self.strings["reply_required"])
            return

        try:
            current = await mx.client.get_state_event(event.room_id, EventType.ROOM_PINNED_EVENTS)
            pinned = list(current.get("pinned", []))
        except Exception:
            pinned = []

        if replied.event_id not in pinned:
            pinned.append(replied.event_id)
        await mx.client.send_state_event(event.room_id, EventType.ROOM_PINNED_EVENTS, {"pinned": pinned})
        await utils.answer(mx, self.strings["pinned"])

    @loader.command()
    async def unpin(self, mx, event):
        """Ответь чтобы открепить, или открепи всё"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)

        try:
            current = await mx.client.get_state_event(event.room_id, EventType.ROOM_PINNED_EVENTS)
            pinned = list(current.get("pinned", []))
        except Exception:
            pinned = []

        if replied and replied.event_id in pinned:
            pinned.remove(replied.event_id)
        elif not replied and pinned:
            pinned = []
        else:
            await utils.answer(mx, self.strings["no_pinned"])
            return

        await mx.client.send_state_event(event.room_id, EventType.ROOM_PINNED_EVENTS, {"pinned": pinned})
        await utils.answer(mx, self.strings["unpinned"])

    @loader.command()
    async def pinned(self, mx, event):
        """Показать закреплённые сообщения"""
        if not await self.check_group(mx, event):
            return
        try:
            current = await mx.client.get_state_event(event.room_id, EventType.ROOM_PINNED_EVENTS)
            pinned = current.get("pinned", [])
        except Exception:
            pinned = []

        if not pinned:
            await utils.answer(mx, self.strings["no_pinned"])
            return

        links = [f"  <a href=\"https://matrix.to/#/{event.room_id}/{eid}\">link</a>" for eid in pinned]
        await utils.answer(mx, self.strings["pinned_msg"].format("<br>".join(links)))

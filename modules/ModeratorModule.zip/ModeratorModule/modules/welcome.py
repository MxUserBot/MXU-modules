#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html


from typing import Any

from pydantic import BaseModel, ConfigDict, model_validator

from .. import loader
from mxc import utils


class WelcomePayload(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    action: str = ""
    text: str = ""

    @model_validator(mode="before")
    @classmethod
    def parse(cls, v: Any):
        if not v or not isinstance(v, str):
            return {"action": ""}
        parts = v.split(maxsplit=1)
        action = parts[0].lower() if parts else ""
        text = parts[1] if len(parts) > 1 else ""
        return {"action": action, "text": text}


class GoodbyePayload(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    action: str = ""
    text: str = ""

    @model_validator(mode="before")
    @classmethod
    def parse(cls, v: Any):
        if not v or not isinstance(v, str):
            return {"action": ""}
        parts = v.split(maxsplit=1)
        action = parts[0].lower() if parts else ""
        text = parts[1] if len(parts) > 1 else ""
        return {"action": action, "text": text}


@loader.command()
async def welcome(self, mx, event, payload: WelcomePayload):
    """set/get/on/off — Welcome message when users join"""
    action = payload.action

    if action == "on":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        await self._set(f"welcome_enabled_{event.room_id}", True)
        await utils.answer(mx, self.strings["welcome_on"])

    elif action == "off":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        await self._set(f"welcome_enabled_{event.room_id}", False)
        await utils.answer(mx, self.strings["welcome_off"])

    elif action == "set":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        media_url = None
        mime = None
        if replied:
            content = replied.content
            file_url = getattr(content, "url", None) or getattr(getattr(content, "file", None), "url", None)
            if file_url:
                media_url = file_url
                try:
                    dl = await utils.download(mx, replied)
                    mime = dl.mimetype
                except Exception:
                    pass
        text = payload.text
        if not text and not media_url:
            await utils.answer(mx, self.strings["welcome_usage_set"])
            return
        await self._set(f"welcome_text_{event.room_id}", text)
        if media_url:
            await self._set(f"welcome_media_{event.room_id}", media_url)
            if mime:
                await self._set(f"welcome_mime_{event.room_id}", mime)
        await utils.answer(mx, self.strings["welcome_set"])

    elif action == "get":
        enabled = await self._get(f"welcome_enabled_{event.room_id}", False)
        text = await self._get(f"welcome_text_{event.room_id}", "")
        media = await self._get(f"welcome_media_{event.room_id}", "")
        status = "✅ on" if enabled else "❌ off"
        t = text or "—"
        m = f"<br>📎 <code>{media}</code>" if media else ""
        await utils.answer(mx, self.strings["welcome_get"].format(status=status, text=t, media=m))

    else:
        await utils.answer(mx, self.strings["welcome_usage"])


@loader.command()
async def goodbye(self, mx, event, payload: GoodbyePayload):
    """set/get/on/off — Goodbye message when users leave"""
    action = payload.action

    if action == "on":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        await self._set(f"goodbye_enabled_{event.room_id}", True)
        await utils.answer(mx, self.strings["goodbye_on"])

    elif action == "off":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        await self._set(f"goodbye_enabled_{event.room_id}", False)
        await utils.answer(mx, self.strings["goodbye_off"])

    elif action == "set":
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        replied = await utils.get_reply_event(mx, event)
        media_url = None
        mime = None
        if replied:
            content = replied.content
            file_url = getattr(content, "url", None) or getattr(getattr(content, "file", None), "url", None)
            if file_url:
                media_url = file_url
                try:
                    dl = await utils.download(mx, replied)
                    mime = dl.mimetype
                except Exception:
                    pass
        text = payload.text
        if not text and not media_url:
            await utils.answer(mx, self.strings["goodbye_usage_set"])
            return
        await self._set(f"goodbye_text_{event.room_id}", text)
        if media_url:
            await self._set(f"goodbye_media_{event.room_id}", media_url)
            if mime:
                await self._set(f"goodbye_mime_{event.room_id}", mime)
        await utils.answer(mx, self.strings["goodbye_set"])

    elif action == "get":
        enabled = await self._get(f"goodbye_enabled_{event.room_id}", False)
        text = await self._get(f"goodbye_text_{event.room_id}", "")
        media = await self._get(f"goodbye_media_{event.room_id}", "")
        status = "✅ on" if enabled else "❌ off"
        t = text or "—"
        m = f"<br>📎 <code>{media}</code>" if media else ""
        await utils.answer(mx, self.strings["goodbye_get"].format(status=status, text=t, media=m))

    else:
        await utils.answer(mx, self.strings["goodbye_usage"])

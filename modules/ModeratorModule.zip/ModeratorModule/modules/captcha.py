#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

import asyncio
import random

from mautrix.types import EventType, Membership, StateEvent, MessageEvent

from .. import loader
from .. import ModeratorModule
from mxc import utils


CAPTCHA_EMOJIS = ["🍎", "🍊", "🍋", "🍇", "🍓", "🍒", "🍑", "🥝", "🍌", "🍉"]


async def _get_captcha_conf(module, room_id: str) -> dict:
    return await module._get(f"captcha_conf_{room_id}", {"enabled": False, "timeout": 60})


async def handle_join(mx, event: StateEvent, module) -> None:
    if event.content.membership != Membership.JOIN:
        return
    if event.state_key == mx.client.mxid:
        return

    conf = await _get_captcha_conf(module, event.room_id)
    if not conf.get("enabled"):
        return

    user_id = event.state_key
    room_id = event.room_id
    emoji = random.choice(CAPTCHA_EMOJIS)

    module._captcha_pending[user_id] = {"room_id": room_id, "emoji": emoji}

    pl = await utils.get_power_levels(mx, room_id)
    if not pl:
        return

    module._captcha_original_pl[user_id] = pl.users.get(user_id, pl.users_default)
    pl.set_user_level(user_id, 0)
    await mx.client.send_state_event(room_id, EventType.ROOM_POWER_LEVELS, pl)

    text = module.strings.get("captcha_prompt").format(emoji=emoji)
    await utils.answer(mx, text, room_id=room_id)

    task = asyncio.create_task(_timeout(mx, room_id, user_id, module))
    module._captcha_pending[user_id]["task"] = task


async def _timeout(mx, room_id, user_id, module):
    conf = await _get_captcha_conf(module, room_id)
    await asyncio.sleep(conf.get("timeout", 60))
    entry = module._captcha_pending.pop(user_id, None)
    if not entry:
        return
    module._captcha_original_pl.pop(user_id, None)
    try:
        await mx.client.kick_user(room_id, user_id, reason="CAPTCHA timeout")
    except Exception:
        pass


async def check_message(mx, event: MessageEvent, module) -> bool:
    user_id = event.sender
    entry = module._captcha_pending.get(user_id)
    if not entry:
        return False

    text = event.content.body or ""
    if text.strip() != entry["emoji"]:
        return False

    entry["task"].cancel()
    module._captcha_pending.pop(user_id, None)
    room_id = entry["room_id"]
    original_level = module._captcha_original_pl.pop(user_id, 0)

    pl = await utils.get_power_levels(mx, room_id)
    if pl:
        level = original_level if original_level > 0 else pl.users_default
        pl.set_user_level(user_id, level)
        await mx.client.send_state_event(room_id, EventType.ROOM_POWER_LEVELS, pl)

    await utils.answer(mx, module.strings.get("captcha_passed"), room_id=room_id)
    return True


class CaptchaCommands(ModeratorModule):
    @loader.command()
    async def addgroup(self, mx, event):
        """Подключить эту комнату к боту"""
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        groups = await self._get("mod_groups", [])
        if event.room_id not in groups:
            groups.append(event.room_id)
            await self._set("mod_groups", groups)
        await utils.answer(mx, self.strings["group_added"])

    @loader.command()
    async def rmgroup(self, mx, event):
        """Отключить эту комнату от бота"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        groups = await self._get("mod_groups", [])
        if event.room_id in groups:
            groups.remove(event.room_id)
            await self._set("mod_groups", groups)
        await utils.answer(mx, self.strings["group_removed"])

    @loader.command()
    async def groups(self, mx, event):
        """Список подключённых комнат"""
        groups = await self._get("mod_groups", [])
        if not groups:
            await utils.answer(mx, self.strings["no_groups"])
            return
        lines = [f"  <code>{r}</code>" for r in groups]
        await utils.answer(mx, self.strings["groups_list"].format("<br>".join(lines)))

    @loader.command()
    async def captcha(self, mx, event, state: str = None):
        """[on/off] — вкл/выкл капчу при входе в эту комнату"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return

        conf = await _get_captcha_conf(self, event.room_id)
        if state and state.lower() in ("on", "yes", "true", "1"):
            conf["enabled"] = True
            await self._set(f"captcha_conf_{event.room_id}", conf)
            await utils.answer(mx, self.strings["captcha_on"])
        elif state and state.lower() in ("off", "no", "false", "0"):
            conf["enabled"] = False
            await self._set(f"captcha_conf_{event.room_id}", conf)
            await utils.answer(mx, self.strings["captcha_off"])
        else:
            current = conf.get("enabled", False)
            await utils.answer(mx, f"Капча: {'✅ вкл' if current else '❌ выкл'}")

    @loader.command()
    async def captchatimeout(self, mx, event, seconds: int = 60):
        """<секунд> — таймаут капчи (10-600), кик если не прошёл"""
        if not await self.check_group(mx, event):
            return
        caller = await self.check_admin(mx, event)
        if not caller:
            return
        seconds = max(10, min(600, seconds))
        conf = await _get_captcha_conf(self, event.room_id)
        conf["timeout"] = seconds
        await self._set(f"captcha_conf_{event.room_id}", conf)
        await utils.answer(mx, self.strings["captcha_timeout_set"].format(t=seconds))

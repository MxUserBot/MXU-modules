#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#			|
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

from typing import Any

from pydantic import BaseModel, ConfigDict, model_validator

from .. import loader
from .. import ModeratorModule
from mxc import utils
from mxc.types.media import DownloadMeta, Image


class NotePayload(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    action: str = ""
    name: str = ""
    text: str = ""

    @model_validator(mode="before")
    @classmethod
    def parse_note(cls, v: Any):
        if not v or not isinstance(v, str):
            return {"action": ""}
        parts = v.split(maxsplit=2)
        action = parts[0].lower() if parts else ""
        name = parts[1] if len(parts) > 1 else ""
        text = parts[2] if len(parts) > 2 else ""
        return {"action": action, "name": name, "text": text}


class NoteCommands(ModeratorModule):
    @loader.command()
    async def note(self, mx, event, payload: NotePayload):
        """add/remove/get/list — управление заметками в комнате"""
        if not await self.check_group(mx, event):
            return

        action = payload.action

        if action == "add":
            await self._note_add(mx, event, payload)
        elif action == "remove":
            await self._note_remove(mx, event, payload)
        elif action == "get":
            await self._note_get(mx, event, payload)
        elif action == "list":
            await self._note_list(mx, event)
        else:
            await utils.answer(mx, self.strings["note_usage"])

    async def _note_add(self, mx, event, payload: NotePayload):
        caller = await self.check_admin(mx, event)
        if not caller:
            return

        name = payload.name
        if not name:
            await utils.answer(mx, self.strings["note_usage_add"])
            return

        replied = await utils.get_reply_event(mx, event)
        if replied:
            body = replied.content.body
            if isinstance(body, bytes):
                body = body.decode("utf-8", errors="replace")
            data = {"text": body}
            try:
                dl = await utils.download(mx, DownloadMeta(url=replied))
                content = replied.content
                file_url = getattr(content, "url", None) or getattr(getattr(content, "file", None), "url", None)
                if file_url:
                    data["mxc"] = file_url
                    data["mime"] = dl.mimetype
            except Exception:
                pass
        else:
            data = {"text": payload.text}

        notes = await self._get(f"notes_{event.room_id}", {})
        if name in notes:
            await utils.answer(mx, self.strings["note_exists"].format(name=name))
            return
        notes[name] = data
        await self._set(f"notes_{event.room_id}", notes)
        await utils.answer(mx, self.strings["note_saved"].format(name=name))

    async def _note_remove(self, mx, event, payload: NotePayload):
        caller = await self.check_admin(mx, event)
        if not caller:
            return

        name = payload.name
        if not name:
            await utils.answer(mx, self.strings["note_usage_remove"])
            return

        ns = await self._get(f"notes_{event.room_id}", {})
        if name not in ns:
            await utils.answer(mx, self.strings["note_not_found"].format(name=name))
            return
        del ns[name]
        await self._set(f"notes_{event.room_id}", ns)
        await utils.answer(mx, self.strings["note_deleted"].format(name=name))

    async def _note_get(self, mx, event, payload: NotePayload):
        name = payload.name
        if not name:
            await utils.answer(mx, self.strings["note_usage_get"])
            return

        notes = await self._get(f"notes_{event.room_id}", {})
        data = notes.get(name)
        if not data:
            await utils.answer(mx, self.strings["note_not_found"].format(name=name))
            return

        text = data.get("text", "")
        mxc = data.get("mxc")
        if mxc:
            await utils.answer(mx, text=text, media=Image(url=mxc, mimetype=data.get("mime", "image/png")))
        else:
            await utils.answer(mx, text or name)

    async def _note_list(self, mx, event):
        ns = await self._get(f"notes_{event.room_id}", {})
        if not ns:
            await utils.answer(mx, self.strings["notes_empty"])
            return
        lines = [f"  <code>{k}</code>" for k in sorted(ns.keys())]
        await utils.answer(mx, self.strings["notes_list"].format("<br>".join(lines)))

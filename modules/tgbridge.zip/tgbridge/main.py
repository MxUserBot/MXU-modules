import asyncio
import json
import traceback
from typing import Any

from mautrix.errors.request import MLimitExceeded
from mautrix.types import EventType, MessageEvent
from telethon import TelegramClient
from telethon.errors import (
    PasswordHashInvalidError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
)
from telethon.sessions import StringSession
from telethon.tl.functions.channels import InviteToChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest

from ... import loader, utils
from ...core.fsm import FSMContext
from .coordinator import BridgeCoordinator
from .dedupe import BridgeDeduplicator, BridgeRelationIndex
from .matrix import MatrixBridgeService
from .models import (
    BootstrapSummary,
    BridgeRuntime,
    HelperInvite,
    HelperLogin,
    SyncSummary,
    TelegramAccountConfig,
    TgBridgeLogin,
    TgPhonePayload,
    _validate_dict,
    _validate_positive_int,
    _validate_string_list,
)
from .state import BridgeStateStore
from .telegram import TelegramAuthService, TelegramBridgeService


@loader.tds
class TelegramBridgeModule(loader.Module):
    strings = {
        "config_required": (
            "\u26a0\ufe0f <b>[TGBridge]</b> Telegram API \u043d\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043d.<br>"
            "\u0417\u0430\u043f\u043e\u043b\u043d\u0438 <code>api_id</code> \u0438 <code>api_hash</code> "
            "\u0447\u0435\u0440\u0435\u0437 <code>.cfg tgbridge ...</code>."
        ),
        "status_header": "<b>[TGBridge]</b> Telegram bridge",
        "status_account_ok": (
            "\u2705 <b>{display}</b> | rooms: <code>{rooms}</code> | space: <code>{space}</code>"
        ),
        "status_account_fail": "\u274c <code>{error}</code>",
        "status_footer": "Matrix->Telegram: <b>{mx_to_tg}</b> | Telegram->Matrix self echo: <b>{tg_echo}</b>",
        "sync_started": "\U0001f504 <b>[TGBridge]</b> \u0417\u0430\u043f\u0443\u0441\u043a\u0430\u044e \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044e \u0434\u0438\u0430\u043b\u043e\u0433\u043e\u0432...",
        "sync_done": "\u2705 <b>[TGBridge]</b> \u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044f \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0430.<br>{details}",
        "bootstrap_started": "\U0001f6e0 <b>[TGBridge]</b> \u0417\u0430\u043f\u0443\u0441\u043a\u0430\u044e bootstrap helper-\u0430\u043a\u043a\u0430\u0443\u043d\u0442\u043e\u0432...",
        "bootstrap_done": "\u2705 <b>[TGBridge]</b> Bootstrap \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043d.<br>{details}",
        "runtime_empty": "\u26a0\ufe0f <b>[TGBridge]</b> \u041d\u0435\u0442 \u043d\u0438 \u043e\u0434\u043d\u043e\u0433\u043e \u0430\u043a\u0442\u0438\u0432\u043d\u043e\u0433\u043e \u0438 \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d\u043d\u043e\u0433\u043e Telegram-\u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430.",
        "runtime_reloaded": "\u267b\ufe0f <b>[TGBridge]</b> Runtime \u043f\u0435\u0440\u0435\u0441\u043e\u0431\u0440\u0430\u043d \u0438\u0437 \u0430\u043a\u0442\u0443\u0430\u043b\u044c\u043d\u043e\u0433\u043e \u043a\u043e\u043d\u0444\u0438\u0433\u0430.",
        "login_phone_prompt": "\u0432\u0430\u0448 \u043d\u043e\u043c\u0435\u0440:",
        "login_code_sent": "\u044f \u043f\u0440\u0438\u0441\u043b\u0430\u043b \u043a\u043e\u0434!<br>\u041a\u043e\u0434:",
        "login_authorized": "\u043e\u0442\u043b\u0438\u0447\u043d\u043e. \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d\u044b",
        "login_need_2fa": "\u043d\u0443\u0436\u0435\u043d \u043f\u0430\u0440\u043e\u043b\u044c 2FA:",
        "login_cancelled": "\U0001f6d1 <b>[TGBridge]</b> \u0410\u0432\u0442\u043e\u0440\u0438\u0437\u0430\u0446\u0438\u044f \u043e\u0442\u043c\u0435\u043d\u0435\u043d\u0430.",
        "login_done": "\u043e\u0442\u043b\u0438\u0447\u043d\u043e. \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d\u044b",
        "login_no_pending": (
            "\u26a0\ufe0f <b>[TGBridge]</b> \u041d\u0435\u0442 \u043e\u0436\u0438\u0434\u0430\u044e\u0449\u0435\u0433\u043e \u043b\u043e\u0433\u0438\u043d\u0430. "
            "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u043f\u043e\u043b\u043d\u0438 <code>.tglogin</code>"
        ),
        "login_invalid_code": "\u274c <b>[TGBridge]</b> \u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0438\u043b\u0438 \u043f\u0440\u043e\u0441\u0440\u043e\u0447\u0435\u043d\u043d\u044b\u0439 \u043a\u043e\u0434.",
        "login_invalid_password": "\u274c <b>[TGBridge]</b> \u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043f\u0430\u0440\u043e\u043b\u044c 2FA.",
        "error": "\u274c <b>[TGBridge]</b> <code>{error}</code>",
    }

    config = {
        "api_id": loader.ConfigValue(
            default=0,
            description="Telegram API ID from my.telegram.org",
            validator=_validate_positive_int,
            required=True,
        ),
        "api_hash": loader.ConfigValue(
            default="",
            description="Telegram API hash from my.telegram.org",
            required=True,
        ),
        "phone_number": loader.ConfigValue(
            default="",
            description="Last Telegram phone used for login",
            forbid=True,
        ),
        "session": loader.ConfigValue(
            default="",
            description="Internal Telethon StringSession",
            forbid=True,
        ),
        "title": loader.ConfigValue(
            default="Telegram",
            description="Display name for the Telegram account space",
        ),
        "invite_targets": loader.ConfigValue(
            default=[],
            description="Global JSON list of Telegram usernames/IDs for helper-account bootstrap invites",
            validator=_validate_string_list,
        ),
        "sync_private_chats": loader.ConfigValue(
            default=True,
            description="Bridge private Telegram dialogs into Matrix rooms",
        ),
        "sync_group_chats": loader.ConfigValue(
            default=False,
            description="Compatibility flag only. Telegram groups and megagroups are never bridged.",
        ),
        "sync_channels": loader.ConfigValue(
            default=True,
            description="Bridge Telegram broadcast channels too",
        ),
        "bridge_bot_dialogs": loader.ConfigValue(
            default=True,
            description="Allow private dialogs with Telegram bots to be bridged",
        ),
        "allow_matrix_to_telegram": loader.ConfigValue(
            default=True,
            description="Relay messages you send in mapped Matrix rooms back to Telegram",
        ),
        "bridge_own_telegram_messages": loader.ConfigValue(
            default=True,
            description="Mirror your own Telegram messages into Matrix too",
        ),
        "auto_create_spaces": loader.ConfigValue(
            default=True,
            description="Compatibility flag. Bridge rooms are always attached to an account Matrix Space.",
        ),
        "auto_sync_on_start": loader.ConfigValue(
            default=True,
            description="Run initial dialog discovery after the bridge lazily boots",
        ),
        "dialog_scan_limit": loader.ConfigValue(
            default=200,
            description="Maximum number of Telegram dialogs to scan during sync/bootstrap",
            validator=_validate_positive_int,
        ),
        "dedupe_ttl": loader.ConfigValue(
            default=600,
            description="Echo suppression TTL in seconds",
            validator=_validate_positive_int,
        ),
        "room_name_template": loader.ConfigValue(
            default="TG | {account} | {title}",
            description="Matrix room name template for bridged dialogs",
        ),
        "space_name_template": loader.ConfigValue(
            default="Telegram | {account}",
            description="Matrix Space name template per account",
        ),
        "bridge_bindings": loader.ConfigValue(
            default={},
            description="Internal Telegram dialog to Matrix room bindings",
            validator=_validate_dict,
            forbid=True,
        ),
        "bridge_spaces": loader.ConfigValue(
            default={},
            description="Internal Telegram account to Matrix Space bindings",
            validator=_validate_dict,
            forbid=True,
        ),
        "pending_logins": loader.ConfigValue(
            default={},
            description="Internal FSM Telegram login checkpoints",
            validator=_validate_dict,
            forbid=True,
        ),
        "message_relations": loader.ConfigValue(
            default={},
            description="Internal Telegram message to Matrix event relation index",
            validator=_validate_dict,
            forbid=True,
        ),
        "encrypt_rooms": loader.ConfigValue(
            default=False,
            description="Encrypt bridged Matrix rooms (m.megolm.v1.aes-sha2)",
        ),
        "helper_session": loader.ConfigValue(
            default="",
            description="Internal Telethon StringSession for helper account",
            forbid=True,
        ),
        "helper_phone": loader.ConfigValue(
            default="",
            description="Phone number for helper account",
            forbid=True,
        ),
        "room_creation_delay": loader.ConfigValue(
            default=15.0,
            description="Delay in seconds between creating Matrix rooms to avoid rate limits",
            validator=lambda x: isinstance(x, (int, float)) and x >= 0,
        ),
        "message_relay_delay": loader.ConfigValue(
            default=2.0,
            description="Delay in seconds between relaying messages to avoid rate limits",
            validator=lambda x: isinstance(x, (int, float)) and x >= 0,
        ),
        "space_attach_batch_size": loader.ConfigValue(
            default=3,
            description="Number of space attachments before a rest period",
            validator=lambda x: isinstance(x, int) and x > 0,
        ),
        "space_attach_batch_delay": loader.ConfigValue(
            default=10,
            description="Seconds to rest after each batch of space attachments",
            validator=lambda x: isinstance(x, (int, float)) and x >= 0,
        ),
    }

    def __init__(self):
        self._runtime: BridgeRuntime | None = None
        self._runtime_lock = asyncio.Lock()
        self._runtime_snapshot = ""

    async def _get_state_store(self) -> BridgeStateStore:
        state = BridgeStateStore(self.config, self.logger)
        await state.load()
        return state

    def _config_ready(self) -> bool:
        return bool(self.config["api_id"] and self.config["api_hash"])

    def _build_account(self, phone_number: str | None = None) -> TelegramAccountConfig:
        if not self._config_ready():
            raise RuntimeError("api_id/api_hash are not configured")

        return TelegramAccountConfig(
            api_id=int(self.config["api_id"]),
            api_hash=self.config["api_hash"],
            phone_number=phone_number or self.config["phone_number"] or None,
            session=self.config["session"] or None,
            title=self.config["title"] or "Telegram",
            bridge_private=self.config["sync_private_chats"],
            bridge_groups=False,
            bridge_channels=self.config["sync_channels"],
            invite_targets=self.config["invite_targets"] or [],
        )

    def _parse_accounts(self) -> list[TelegramAccountConfig]:
        return [self._build_account()] if self._config_ready() else []

    async def _set_config_value(self, key: str, value: Any):
        if hasattr(self.config, "set_async"):
            saved = await self.config.set_async(key, value)
        else:
            saved = self.config.set(key, value)

        if not saved:
            raise RuntimeError(f"failed to update config key '{key}'")

    async def _save_session(self, account: TelegramAccountConfig, session: str):
        await self._set_config_value("session", session)
        if account.phone_number:
            await self._set_config_value("phone_number", account.phone_number)

    def _build_runtime_snapshot(self, accounts: list[TelegramAccountConfig]) -> str:
        payload = {
            "account": accounts[0].model_dump() if accounts else {},
            "sync_private_chats": self.config["sync_private_chats"],
            "sync_channels": self.config["sync_channels"],
            "bridge_bot_dialogs": self.config["bridge_bot_dialogs"],
            "allow_matrix_to_telegram": self.config["allow_matrix_to_telegram"],
            "bridge_own_telegram_messages": self.config["bridge_own_telegram_messages"],
            "auto_sync_on_start": self.config["auto_sync_on_start"],
            "dialog_scan_limit": self.config["dialog_scan_limit"],
            "dedupe_ttl": self.config["dedupe_ttl"],
            "room_name_template": self.config["room_name_template"],
            "space_name_template": self.config["space_name_template"],
            "invite_targets": self.config["invite_targets"],
            "room_creation_delay": self.config["room_creation_delay"],
            "message_relay_delay": self.config["message_relay_delay"],
        }
        return json.dumps(payload, sort_keys=True, ensure_ascii=False)

    async def _shutdown_runtime(self):
        if self._runtime is None:
            return

        task = self._runtime.initial_sync_task
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        await self._runtime.telegram.stop()
        self._runtime = None
        self._runtime_snapshot = ""

    async def _build_runtime(self, mx: Any, accounts: list[TelegramAccountConfig]) -> BridgeRuntime:
        state = BridgeStateStore(self.config, self.logger)
        await state.load()

        dedupe = BridgeDeduplicator(self.config["dedupe_ttl"])
        relations = BridgeRelationIndex(initial=state.get_relations())
        matrix_service = MatrixBridgeService(mx, self, state, self.logger)

        coordinator_ref: dict[str, BridgeCoordinator] = {}

        async def event_listener(account_alias: str, event: Any):
            coordinator = coordinator_ref.get("value")
            if coordinator is None:
                return
            await coordinator.handle_telegram_event(account_alias, event)

        telegram_service = TelegramBridgeService(self, self.logger, event_listener)
        coordinator = BridgeCoordinator(
            module=self,
            logger=self.logger,
            matrix_service=matrix_service,
            telegram_service=telegram_service,
            state=state,
            dedupe=dedupe,
            relations=relations,
        )
        coordinator_ref["value"] = coordinator

        await telegram_service.start(accounts)

        runtime = BridgeRuntime(
            mx=mx,
            state=state,
            dedupe=dedupe,
            relations=relations,
            matrix=matrix_service,
            telegram=telegram_service,
            coordinator=coordinator,
        )

        if self.config["auto_sync_on_start"]:
            runtime.initial_sync_task = asyncio.create_task(self._run_initial_sync(runtime))

        return runtime

    async def _run_initial_sync(self, runtime: BridgeRuntime):
        try:
            await runtime.coordinator.sync_dialogs()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.logger.error(f"[TGBridge] Initial sync failed: {exc}")
        finally:
            runtime.initial_sync_done = True

    async def _ensure_runtime(self, mx: Any, fail_silently: bool = False) -> BridgeRuntime | None:
        try:
            accounts = self._parse_accounts()
        except Exception:
            if fail_silently:
                return None
            raise

        if not accounts:
            if fail_silently:
                return None
            raise RuntimeError("Telegram API credentials are not configured")

        snapshot = self._build_runtime_snapshot(accounts)

        async with self._runtime_lock:
            if self._runtime is not None and self._runtime_snapshot == snapshot:
                return self._runtime

            await self._shutdown_runtime()
            self._runtime = await self._build_runtime(mx, accounts)
            self._runtime_snapshot = snapshot
            self.logger.info("[TGBridge] Runtime initialized, bridge active")
            return self._runtime

    def _format_status(self, accounts: list[TelegramAccountConfig], runtime: BridgeRuntime | None) -> str:
        lines = [self.strings["status_header"]]

        if runtime is None:
            lines.append(self.strings["runtime_empty"])
            return "<br>".join(lines)

        for account in accounts:
            active = runtime.telegram.get_runtime(account.alias)
            if active is not None:
                room_count = len(runtime.state.list_bindings_for_account(account.alias))
                space_id = runtime.state.get_space(account.alias) or "\u2014"
                lines.append(
                    self.strings["status_account_ok"].format(
                        display=utils.escape_html(active.me_display or account.title or "Telegram"),
                        rooms=room_count,
                        space=utils.escape_html(space_id),
                    )
                )
                continue

            error = runtime.telegram.start_errors.get(account.alias, "runtime inactive")
            lines.append(
                self.strings["status_account_fail"].format(
                    error=utils.escape_html(error),
                )
            )

        lines.append(
            self.strings["status_footer"].format(
                mx_to_tg="on" if self.config["allow_matrix_to_telegram"] else "off",
                tg_echo="on" if self.config["bridge_own_telegram_messages"] else "off",
            )
        )
        return "<br>".join(lines)

    def _format_sync_details(self, summaries: list[SyncSummary]) -> str:
        if not summaries:
            return self.strings["runtime_empty"]

        return "<br>".join(
            (
                f"created=<code>{summary.created}</code> "
                f"existing=<code>{summary.existing}</code> "
                f"skipped=<code>{summary.skipped}</code> "
                f"failed=<code>{summary.failed}</code>"
            )
            for summary in summaries
        )

    def _format_bootstrap_details(self, summaries: list[BootstrapSummary]) -> str:
        if not summaries:
            return self.strings["runtime_empty"]

        return "<br>".join(
            (
                f"attempted=<code>{summary.attempted}</code> "
                f"invited=<code>{summary.invited}</code> "
                f"skipped=<code>{summary.skipped}</code> "
                f"failed=<code>{summary.failed}</code>"
            )
            for summary in summaries
        )

    async def _answer(self, mx, text=None, **kwargs):
        event = kwargs.get("event")
        room_id = getattr(event, "room_id", getattr(mx, "_current_event", None))
        if hasattr(room_id, "room_id"):
            room_id = room_id.room_id
        sender = getattr(event, "sender", "?")
        source_id = getattr(event, "event_id", None) or getattr(getattr(mx, "_current_event", None), "event_id", None)
        for attempt in range(20):
            try:
                event_id = await utils.answer(mx, text, **kwargs)
                if hasattr(mx, "_ignore_ids"):
                    if event_id:
                        mx._ignore_ids.add(event_id)
                    if source_id:
                        mx._ignore_ids.add(source_id)
                if hasattr(mx, "fsm"):
                    if event_id:
                        mx.fsm.mark_outgoing(event_id)
                    if source_id:
                        mx.fsm.mark_outgoing(source_id)
                return event_id
            except MLimitExceeded as exc:
                retry_after = getattr(exc, "retry_after_ms", 5000) / 1000
                wait = min(retry_after, 60)
                if attempt == 0:
                    tb = "".join(traceback.format_stack(limit=10))
                    self.logger.warning(
                        f"[TGBridge] _answer called (room={room_id}, sender={sender}, "
                        f"text={text!r:.80})\nCall stack:\n{tb}"
                    )
                self.logger.warning(f"[TGBridge] 429 on answer, retry in {wait:.1f}s ({attempt + 1}/20)")
                await asyncio.sleep(wait)
        self.logger.error(f"[TGBridge] 429 on answer, giving up after 20 retries")

    @loader.command()
    async def tgbridge(self, mx, event: MessageEvent):
        """| \u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435 Telegram bridge"""
        accounts = self._parse_accounts()
        if not accounts:
            return await self._answer(mx, self.strings["config_required"])

        runtime = await self._ensure_runtime(mx)
        await self._answer(mx, self._format_status(accounts, runtime))

    def _is_login_cancel(self, text: str) -> bool:
        return text.strip().lower() in {"cancel", "\u043e\u0442\u043c\u0435\u043d\u0430", "\u0441\u0442\u043e\u043f"}

    async def _finish_login_with_session(self, account: TelegramAccountConfig, session: str):
        account.session = session
        await self._save_session(account, session)
        await self._shutdown_runtime()

    async def _complete_login_code(self, account: TelegramAccountConfig, code: str) -> str:
        state = await self._get_state_store()
        if state.get_pending_login() is None:
            return self.strings["login_no_pending"]

        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.sign_in(account, code.replace(" ", ""))
        except (PhoneCodeInvalidError, PhoneCodeExpiredError):
            return self.strings["login_invalid_code"]

        if result.get("password_required"):
            return self.strings["login_need_2fa"]

        session = result.get("session")
        if not session:
            return self.strings["error"].format(error="empty session after sign-in")

        await self._finish_login_with_session(account, session)
        return self.strings["login_done"]

    async def _complete_login_password(self, account: TelegramAccountConfig, password: str) -> str:
        state = await self._get_state_store()
        if state.get_pending_login() is None:
            return self.strings["login_no_pending"]

        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.sign_in_with_password(account, password)
        except PasswordHashInvalidError:
            return self.strings["login_invalid_password"]

        session = result.get("session")
        if not session:
            return self.strings["error"].format(error="empty session after 2FA sign-in")

        await self._finish_login_with_session(account, session)
        return self.strings["login_done"]

    async def _build_helper_account(self) -> TelegramAccountConfig | None:
        if not self._config_ready():
            return None
        session = self.config.get("helper_session", "")
        phone = self.config.get("helper_phone", "")
        if not session:
            return None
        return TelegramAccountConfig(
            api_id=int(self.config["api_id"]),
            api_hash=self.config["api_hash"],
            phone_number=phone or None,
            session=session or None,
            title="Helper",
            bridge_private=False,
            bridge_groups=False,
            bridge_channels=False,
        )

    async def _save_helper_session(self, session: str, phone: str):
        await self._set_config_value("helper_session", session)
        await self._set_config_value("helper_phone", phone)

    async def _show_post_login_menu(self, mx, event):
        async def handle_choice(ctx):
            if ctx.payload == "helper":
                fsm_ctx = FSMContext(mx.fsm, event)
                await fsm_ctx.set_state(HelperLogin.phone)
                await ctx.edit("\U0001f4f1 <b>\u0412\u0432\u0435\u0434\u0438 \u043d\u043e\u043c\u0435\u0440 helper \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430</b> (\u0438\u043b\u0438 <code>-</code> \u0434\u043b\u044f \u043e\u0442\u043c\u0435\u043d\u044b):")
            elif ctx.payload == "encrypt":
                current = self.config.get("encrypt_rooms", False)
                await self._set_config_value("encrypt_rooms", not current)
                status = "\u0432\u043a\u043b\u044e\u0447\u0435\u043d\u043e" if not current else "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"
                await ctx.edit(f"\U0001f512 <b>\u0428\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u043d\u0430\u0442: {status}</b>")
                await ctx.close(clear_reactions=True)
            else:
                await ctx.edit("\u2705 <b>\u0413\u043e\u0442\u043e\u0432\u043e!</b>")
                await ctx.close(clear_reactions=True)

        markup = utils.EmojiKeyBoard(
            rows=[[
                utils.EmojiButton("1\ufe0f\u20e3", "helper"),
                utils.EmojiButton("2\ufe0f\u20e3", "encrypt"),
                utils.EmojiButton("3\ufe0f\u20e3", "done"),
            ]],
            callback=handle_choice,
            allowed_senders=[event.sender],
            single_use=True,
            timeout=120,
        )

        await self._answer(
            mx,
            "\u2705 <b>\u0410\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d!</b><br>"
            "1\ufe0f\u20e3 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c helper \u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u0434\u043b\u044f \u0438\u043d\u0432\u0430\u0439\u0442\u0430<br>"
            "2\ufe0f\u20e3 \u0428\u0438\u0444\u0440\u043e\u0432\u0430\u0442\u044c \u043a\u043e\u043c\u043d\u0430\u0442\u044b<br>"
            "3\ufe0f\u20e3 \u0413\u043e\u0442\u043e\u0432\u043e",
            event=event,
            reply_markup=markup,
        )

    @loader.command()
    async def tglogin(self, mx, event: MessageEvent):
        """| \u0410\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u0442\u044c Telegram \u0447\u0435\u0440\u0435\u0437 FSM"""
        if not self._config_ready():
            return await self._answer(mx, self.strings["config_required"])

        ctx = FSMContext(mx.fsm, event)
        await ctx.set_state(TgBridgeLogin.phone)
        await self._answer(mx, self.strings["login_phone_prompt"])

    @loader.state(TgBridgeLogin.phone)
    async def tglogin_phone_state(self, mx, event: MessageEvent, ctx: FSMContext, payload: TgPhonePayload):
        if self._is_login_cancel(payload.phone_number):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account(payload.phone_number)
        state = await self._get_state_store()
        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.send_code(account, payload.phone_number)
        except Exception as exc:
            self.logger.warning(f"[TGBridge] tglogin_phone_state send_code failed: {exc}")
            return

        if result.get("authorized"):
            session = result.get("session")
            if session:
                await self._finish_login_with_session(account, session)
            await ctx.clear()
            await self._answer(mx, self.strings["login_authorized"], event=event)
            await self._show_post_login_menu(mx, event)
            return

        await self._set_config_value("phone_number", payload.phone_number)
        await ctx.set_state(TgBridgeLogin.code)
        await self._answer(mx, self.strings["login_code_sent"], event=event)

    @loader.state(TgBridgeLogin.code)
    async def tglogin_code_state(self, mx, event: MessageEvent, ctx: FSMContext, code: str):
        if self._is_login_cancel(code):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account()
        message = await self._complete_login_code(account, code)

        if message == self.strings["login_invalid_code"]:
            return await self._answer(mx, message, event=event)

        if message == self.strings["login_need_2fa"]:
            await ctx.set_state(TgBridgeLogin.password)
            return await self._answer(mx, message, event=event)

        await ctx.clear()
        await self._answer(mx, message, event=event)
        await self._show_post_login_menu(mx, event)

    @loader.state(TgBridgeLogin.password)
    async def tglogin_password_state(self, mx, event: MessageEvent, ctx: FSMContext, password: str):
        if self._is_login_cancel(password):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account()
        message = await self._complete_login_password(account, password)

        if message != self.strings["login_invalid_password"]:
            await ctx.clear()
            await self._answer(mx, message, event=event)
            await self._show_post_login_menu(mx, event)
            return

        await self._answer(mx, message, event=event)

    @loader.state(HelperLogin.phone)
    async def helper_phone_state(self, mx, event: MessageEvent, ctx: FSMContext, payload: TgPhonePayload):
        if self._is_login_cancel(payload.phone_number):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account(payload.phone_number)
        state = await self._get_state_store()
        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.send_code(account, payload.phone_number)
        except Exception as exc:
            return await self._answer(mx, self.strings["error"].format(error=utils.escape_html(str(exc))), event=event)

        if result.get("authorized"):
            session = result.get("session")
            if session:
                await self._save_helper_session(session, payload.phone_number)
            await ctx.clear()
            await self._answer(mx, "\u2705 <b>Helper \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d!</b>", event=event)
            await self._run_helper_bootstrap(mx, event)
            return

        await self._set_config_value("helper_phone", payload.phone_number)
        await ctx.set_state(HelperLogin.code)
        await self._answer(mx, self.strings["login_code_sent"], event=event)

    @loader.state(HelperLogin.code)
    async def helper_code_state(self, mx, event: MessageEvent, ctx: FSMContext, code: str):
        if self._is_login_cancel(code):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account(self.config.get("helper_phone", ""))
        result = await self._complete_helper_login_code(account, code)

        if result == "2fa":
            await ctx.set_state(HelperLogin.password)
            return await self._answer(mx, self.strings["login_need_2fa"], event=event)

        if result is True:
            await ctx.clear()
            await self._answer(mx, "\u2705 <b>Helper \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d!</b>", event=event)
            await self._run_helper_bootstrap(mx, event)
            return

        await self._answer(mx, result, event=event)

    @loader.state(HelperLogin.password)
    async def helper_password_state(self, mx, event: MessageEvent, ctx: FSMContext, password: str):
        if self._is_login_cancel(password):
            await ctx.clear()
            return await self._answer(mx, self.strings["login_cancelled"], event=event)

        account = self._build_account(self.config.get("helper_phone", ""))
        ok = await self._complete_helper_login_password(account, password)

        if ok:
            await ctx.clear()
            await self._answer(mx, "\u2705 <b>Helper \u0430\u0432\u0442\u043e\u0440\u0438\u0437\u043e\u0432\u0430\u043d!</b>", event=event)
            await self._run_helper_bootstrap(mx, event)
            return

        await self._answer(mx, self.strings["login_invalid_password"], event=event)

    async def _complete_helper_login_code(self, account: TelegramAccountConfig, code: str) -> bool | str:
        state = await self._get_state_store()
        if state.get_pending_login() is None:
            return self.strings["login_no_pending"]

        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.sign_in(account, code.replace(" ", ""))
        except (PhoneCodeInvalidError, PhoneCodeExpiredError):
            return self.strings["login_invalid_code"]

        if result.get("password_required"):
            return "2fa"

        session = result.get("session")
        if not session:
            return self.strings["error"].format(error="empty session after sign-in")

        await self._save_helper_session(session, account.phone_number or "")
        return True

    async def _complete_helper_login_password(self, account: TelegramAccountConfig, password: str) -> bool:
        state = await self._get_state_store()
        if state.get_pending_login() is None:
            return False

        auth = TelegramAuthService(self, state, self.logger)
        try:
            result = await auth.sign_in_with_password(account, password)
        except PasswordHashInvalidError:
            return False

        session = result.get("session")
        if not session:
            return False

        await self._save_helper_session(session, account.phone_number or "")
        return True

    async def _run_helper_bootstrap(self, mx, event):
        targets = self.config.get("invite_targets", []) or []

        if not targets:
            async def handle_target(ctx):
                if ctx.payload == "yes":
                    fsm_ctx = FSMContext(mx.fsm, event)
                    await fsm_ctx.set_state(HelperInvite.target)
                    await ctx.edit("\U0001f464 <b>\u0412\u0432\u0435\u0434\u0438 username \u0434\u043b\u044f \u0438\u043d\u0432\u0430\u0439\u0442\u0430</b> (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, @username):")
                else:
                    await ctx.edit("\u2705 <b>\u041f\u0440\u043e\u043f\u0443\u0449\u0435\u043d\u043e</b>")
                    await ctx.close(clear_reactions=True)
                    await self._show_encrypt_toggle(mx, event)

            markup = utils.EmojiKeyBoard(
                rows=[[
                    utils.EmojiButton("\u2705", "yes"),
                    utils.EmojiButton("\u274c", "no"),
                ]],
                callback=handle_target,
                allowed_senders=[event.sender],
                single_use=True,
                timeout=60,
            )

            await self._answer(
                mx,
                "\U0001f464 <b>\u041f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u0442\u044c \u043e\u0441\u043d\u043e\u0432\u0443 \u0432 Telegram \u0447\u0430\u0442\u044b?</b>",
                event=event,
                reply_markup=markup,
            )
            return

        await self._do_bootstrap(mx, event, targets)

    @loader.state(HelperInvite.target)
    async def helper_invite_state(self, mx, event: MessageEvent, ctx: FSMContext, target: str):
        if self._is_login_cancel(target):
            await ctx.clear()
            return await self._answer(mx, "\u2705 <b>\u041f\u0440\u043e\u043f\u0443\u0449\u0435\u043d\u043e</b>", event=event)

        await ctx.clear()
        await self._do_bootstrap(mx, event, [target.strip()])

    async def _do_bootstrap(self, mx, event, targets: list[str]):
        helper_session = self.config.get("helper_session", "")
        if not helper_session:
            await self._answer(mx, "\u274c <b>Helper \u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u043d\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043d. \u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0434\u043e\u0431\u0430\u0432\u044c helper.</b>")
            await self._show_encrypt_toggle(mx, event)
            return

        client = TelegramClient(
            StringSession(helper_session),
            int(self.config["api_id"]),
            self.config["api_hash"],
            sequential_updates=True,
        )

        try:
            await client.connect()
            if not await client.is_user_authorized():
                raise RuntimeError("helper account is not authorized")

            resolved = []
            for raw in targets:
                try:
                    resolved.append(await client.get_input_entity(raw))
                except Exception as exc:
                    self.logger.warning(f"[TGBridge] Failed to resolve '{raw}': {exc}")

            if not resolved:
                await self._answer(mx, "\u274c <b>\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0439\u0442\u0438 \u043d\u0438 \u043e\u0434\u043d\u043e\u0433\u043e target \u0434\u043b\u044f \u0438\u043d\u0432\u0430\u0439\u0442\u0430</b>")
                return

            invited = 0
            failed = 0

            await self._answer(mx, f"\U0001f6e0 <b>\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0430\u044e {len(resolved)} target(\u043e\u0432) \u0432 \u0447\u0430\u0442\u044b...</b>")

            async for dialog in client.iter_dialogs(limit=self.config.get("dialog_scan_limit", 200)):
                if dialog.is_user or getattr(dialog.entity, "bot", False):
                    continue
                for target in resolved:
                    try:
                        if getattr(dialog.entity, "megagroup", False) or dialog.entity.__class__.__name__.lower().endswith("channel"):
                            await client(InviteToChannelRequest(dialog.entity, [target]))
                        else:
                            await client(AddChatUserRequest(dialog.entity.id, target, fwd_limit=10))
                        invited += 1
                    except Exception as exc:
                        err = str(exc).lower()
                        if "already" in err or "participant" in err:
                            continue
                        failed += 1

            await self._answer(
                mx,
                f"\u2705 <b>\u0418\u043d\u0432\u0430\u0439\u0442 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043d.</b><br>"
                f"\u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u043e: <code>{invited}</code><br>"
                f"\u043e\u0448\u0438\u0431\u043e\u043a: <code>{failed}</code>",
            )

            runtime = await self._ensure_runtime(mx, fail_silently=True)
            if runtime:
                await self._answer(mx, "\U0001f504 <b>\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0438\u0440\u0443\u044e \u0434\u0438\u0430\u043b\u043e\u0433\u0438 \u043e\u0441\u043d\u043e\u0432\u043d\u043e\u0433\u043e \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u0430...</b>")
                sync_summaries = await runtime.coordinator.sync_dialogs()
                await self._answer(mx, f"\u2705 <b>\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044f:</b> {self._format_sync_details(sync_summaries)}")

        except Exception as exc:
            self.logger.error(f"[TGBridge] Bootstrap error: {exc}")
            await self._answer(mx, f"\u274c <b>Bootstrap error:</b> <code>{utils.escape_html(str(exc))}</code>")
        finally:
            await client.disconnect()
            await self._show_encrypt_toggle(mx, event)

    async def _show_encrypt_toggle(self, mx, event):
        async def handle_choice(ctx):
            current = self.config.get("encrypt_rooms", False)
            await self._set_config_value("encrypt_rooms", not current)
            status = "\u0432\u043a\u043b\u044e\u0447\u0435\u043d\u043e" if not current else "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"
            await ctx.edit(f"\U0001f512 <b>\u0428\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u043d\u0430\u0442: {status}</b>")
            await ctx.close(clear_reactions=True)

        markup = utils.EmojiKeyBoard(
            rows=[[
                utils.EmojiButton("\u2705", "yes"),
                utils.EmojiButton("\u274c", "no"),
            ]],
            callback=handle_choice,
            allowed_senders=[event.sender],
            single_use=True,
            timeout=60,
        )

        await self._answer(
            mx,
            "\U0001f512 <b>\u0428\u0438\u0444\u0440\u043e\u0432\u0430\u0442\u044c bridged \u043a\u043e\u043c\u043d\u0430\u0442\u044b?</b>",
            event=event,
            reply_markup=markup,
        )

    @loader.command()
    async def tgsync(self, mx, event: MessageEvent):
        """| \u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u0442\u044c Telegram-\u0434\u0438\u0430\u043b\u043e\u0433\u0438 \u0438 \u0441\u043e\u0437\u0434\u0430\u0442\u044c Matrix rooms/spaces"""
        accounts = self._parse_accounts()
        if not accounts:
            return await self._answer(mx, self.strings["config_required"])

        runtime = await self._ensure_runtime(mx)
        if runtime is None or not runtime.telegram.runtimes:
            return await self._answer(mx, self.strings["runtime_empty"])

        await self._answer(mx, self.strings["sync_started"])
        summaries = await runtime.coordinator.sync_dialogs()
        await self._answer(mx, self.strings["sync_done"].format(details=self._format_sync_details(summaries)))

    @loader.command()
    async def tgbootstrap(self, mx, event: MessageEvent):
        """| Helper-\u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0430\u0435\u0442 \u0446\u0435\u043b\u0435\u0432\u044b\u0435 \u0430\u043a\u043a\u0430\u0443\u043d\u0442\u044b \u0432 TG-\u0447\u0430\u0442\u044b \u0438 \u0433\u043e\u0442\u043e\u0432\u0438\u0442 Matrix Spaces"""
        accounts = self._parse_accounts()
        if not accounts:
            return await self._answer(mx, self.strings["config_required"])

        runtime = await self._ensure_runtime(mx)
        if runtime is None or not runtime.telegram.runtimes:
            return await self._answer(mx, self.strings["runtime_empty"])

        await self._answer(mx, self.strings["bootstrap_started"])
        bootstrap_summaries = await runtime.coordinator.bootstrap_accounts()
        sync_summaries = await runtime.coordinator.sync_dialogs()

        details = (
            f"{self._format_bootstrap_details(bootstrap_summaries)}"
            f"<br><br><b>Post-sync:</b><br>{self._format_sync_details(sync_summaries)}"
        )
        await self._answer(mx, self.strings["bootstrap_done"].format(details=details))

    @loader.on(EventType.ROOM_MESSAGE)
    async def matrix_bridge_handler(self, mx, event: MessageEvent):
        runtime = await self._ensure_runtime(mx, fail_silently=True)
        if runtime is None:
            return

        try:
            await runtime.coordinator.handle_matrix_message(mx, event)
        except Exception as exc:
            self.logger.error(f"[TGBridge] Matrix->Telegram bridge error: {exc}")

    @loader.on(EventType.STICKER)
    async def matrix_sticker_bridge_handler(self, mx, event: MessageEvent):
        await self.matrix_bridge_handler(mx, event)

    @loader.on(EventType.ROOM_MEMBER)
    async def matrix_bridge_warmup(self, mx, _):
        await self._ensure_runtime(mx, fail_silently=True)

    async def _matrix_start(self, mx):
        if self._config_ready():
            asyncio.create_task(self._ensure_runtime(mx, fail_silently=True))

    async def _matrix_stop(self, mx):
        await self._shutdown_runtime()

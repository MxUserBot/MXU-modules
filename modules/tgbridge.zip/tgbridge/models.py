from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .coordinator import BridgeCoordinator
    from .dedupe import BridgeDeduplicator, BridgeRelationIndex
    from .matrix import MatrixBridgeService
    from .state import BridgeStateStore
    from .telegram import TelegramBridgeService

from mautrix.types import MessageType
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ...core.fsm import State, StatesGroup

DEFAULT_ACCOUNT_ALIAS = "telegram"


class TelegramAccountConfig(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    alias: str = DEFAULT_ACCOUNT_ALIAS
    api_id: int
    api_hash: str
    phone_number: str | None = None
    session: str | None = None
    session_name: str | None = None
    enabled: bool = True
    title: str | None = None
    bridge_private: bool = True
    bridge_groups: bool = False
    bridge_channels: bool = True
    invite_targets: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def finalize(self):
        self.alias = DEFAULT_ACCOUNT_ALIAS

        if not self.session_name and not self.session:
            self.session_name = str(Path(".tgbridge_sessions") / DEFAULT_ACCOUNT_ALIAS)

        if not self.title:
            self.title = "Telegram"

        self.invite_targets = [str(item).strip() for item in self.invite_targets if str(item).strip()]
        return self


class DialogBinding(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    account_alias: str
    peer_id: int
    peer_type: str
    title: str
    room_id: str
    space_id: str | None = None
    is_direct: bool = False

    @property
    def key(self) -> str:
        return f"{self.account_alias}:{self.peer_id}"


@dataclass
class BridgeDialog:
    account_alias: str
    peer_id: int
    peer_type: str
    title: str
    is_direct: bool
    entity: Any = None

    @property
    def key(self) -> str:
        return f"{self.account_alias}:{self.peer_id}"


@dataclass
class BridgeMessage:
    plain_text: str
    html_text: str
    reply_to_telegram_id: int | None = None
    media_kind: str | None = None
    media_bytes: bytes | None = None
    mimetype: str | None = None
    filename: str | None = None
    size: int | None = None
    width: int | None = None
    height: int | None = None
    duration: int | None = None
    voice_note: bool = False

    @property
    def has_media(self) -> bool:
        return self.media_bytes is not None


@dataclass
class SyncSummary:
    account_alias: str
    created: int = 0
    existing: int = 0
    skipped: int = 0
    failed: int = 0


@dataclass
class BootstrapSummary:
    account_alias: str
    attempted: int = 0
    invited: int = 0
    skipped: int = 0
    failed: int = 0


@dataclass
class MatrixOutboundMessage:
    text: str = ""
    reply_to_telegram_id: int | None = None
    media_bytes: bytes | None = None
    mimetype: str | None = None
    filename: str | None = None
    msgtype: MessageType | str | None = None
    voice_note: bool = False

    @property
    def has_media(self) -> bool:
        return self.media_bytes is not None


@dataclass
class TelegramAccountRuntime:
    config: TelegramAccountConfig
    client: Any
    me_id: int | None = None
    me_display: str = ""


@dataclass
class BridgeRuntime:
    mx: Any
    state: BridgeStateStore
    dedupe: BridgeDeduplicator
    relations: BridgeRelationIndex
    matrix: MatrixBridgeService
    telegram: TelegramBridgeService
    coordinator: BridgeCoordinator
    initial_sync_done: bool = False
    initial_sync_task: asyncio.Task | None = None


class PendingLogin(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    phone_number: str
    phone_code_hash: str
    session: str = ""


class TgBridgeLogin(StatesGroup):
    phone = State()
    code = State()
    password = State()


class HelperLogin(StatesGroup):
    phone = State()
    code = State()
    password = State()


class HelperInvite(StatesGroup):
    target = State()


class TgPhonePayload(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    phone_number: str = Field(min_length=1)

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: Any):
        if isinstance(value, str):
            return {"phone_number": value.strip()}
        return value


def _validate_positive_int(value: Any) -> bool:
    return isinstance(value, int) and value > 0


def _validate_string_list(value: Any) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


def _validate_dict(value: Any) -> bool:
    return isinstance(value, dict)

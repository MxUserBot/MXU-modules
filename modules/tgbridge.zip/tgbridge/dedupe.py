import time
from collections import OrderedDict
from typing import Any


class BridgeDeduplicator:
    def __init__(self, ttl_seconds: int):
        self.ttl_seconds = ttl_seconds
        self._matrix_events: dict[str, float] = {}
        self._telegram_events: dict[tuple[str, int, int], float] = {}

    def _prune(self):
        now = time.monotonic()
        self._matrix_events = {
            event_id: ts for event_id, ts in self._matrix_events.items() if now - ts < self.ttl_seconds
        }
        self._telegram_events = {
            key: ts for key, ts in self._telegram_events.items() if now - ts < self.ttl_seconds
        }

    def remember_matrix(self, event_id: str):
        self._prune()
        self._matrix_events[event_id] = time.monotonic()

    def consume_matrix(self, event_id: str) -> bool:
        self._prune()
        return self._matrix_events.pop(event_id, None) is not None

    def remember_telegram(self, account_alias: str, peer_id: int, message_id: int):
        self._prune()
        self._telegram_events[(account_alias, peer_id, message_id)] = time.monotonic()

    def consume_telegram(self, account_alias: str, peer_id: int, message_id: int) -> bool:
        self._prune()
        return self._telegram_events.pop((account_alias, peer_id, message_id), None) is not None


class BridgeRelationIndex:
    def __init__(self, limit_per_binding: int = 500, initial: dict[str, Any] | None = None):
        self.limit_per_binding = limit_per_binding
        self._tg_to_mx: dict[str, OrderedDict[int, str]] = {}
        self._mx_to_tg: dict[str, OrderedDict[str, int]] = {}
        if initial:
            self.load(initial)

    def load(self, payload: dict[str, Any]):
        raw_tg_to_mx = payload.get("tg_to_mx", {}) if isinstance(payload, dict) else {}
        raw_mx_to_tg = payload.get("mx_to_tg", {}) if isinstance(payload, dict) else {}

        for binding_key, mapping in raw_tg_to_mx.items():
            if not isinstance(mapping, dict):
                continue
            self._tg_to_mx[str(binding_key)] = OrderedDict(
                (int(tg_id), str(mx_id))
                for tg_id, mx_id in mapping.items()
                if str(tg_id).lstrip("-").isdigit()
            )

        for binding_key, mapping in raw_mx_to_tg.items():
            if not isinstance(mapping, dict):
                continue
            self._mx_to_tg[str(binding_key)] = OrderedDict(
                (str(mx_id), int(tg_id))
                for mx_id, tg_id in mapping.items()
                if str(tg_id).lstrip("-").isdigit()
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "tg_to_mx": {
                binding_key: {str(tg_id): mx_id for tg_id, mx_id in mapping.items()}
                for binding_key, mapping in self._tg_to_mx.items()
            },
            "mx_to_tg": {
                binding_key: {mx_id: tg_id for mx_id, tg_id in mapping.items()}
                for binding_key, mapping in self._mx_to_tg.items()
            },
        }

    def remember(self, binding_key: str, telegram_message_id: int, matrix_event_id: str):
        tg_map = self._tg_to_mx.setdefault(binding_key, OrderedDict())
        mx_map = self._mx_to_tg.setdefault(binding_key, OrderedDict())

        tg_map[telegram_message_id] = matrix_event_id
        tg_map.move_to_end(telegram_message_id)
        mx_map[matrix_event_id] = telegram_message_id
        mx_map.move_to_end(matrix_event_id)

        while len(tg_map) > self.limit_per_binding:
            tg_map.popitem(last=False)
        while len(mx_map) > self.limit_per_binding:
            mx_map.popitem(last=False)

    def get_matrix_event(self, binding_key: str, telegram_message_id: int | None) -> str | None:
        if telegram_message_id is None:
            return None
        mapping = self._tg_to_mx.get(binding_key)
        if mapping is None:
            return None
        return mapping.get(telegram_message_id)

    def get_telegram_message(self, binding_key: str, matrix_event_id: str | None) -> int | None:
        if matrix_event_id is None:
            return None
        mapping = self._mx_to_tg.get(binding_key)
        if mapping is None:
            return None
        return mapping.get(matrix_event_id)

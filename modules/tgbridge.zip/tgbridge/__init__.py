class Meta:
    name = "TelegramBridge"
    description = "Telegram bridge with multi-account sync, Matrix Spaces and helper account bootstrap."
    version = "4.0.0"
    dependencies = ["telethon"]
    tags = ["bridge", "telegram", "matrix"]
    author = "@pasha:pashahatsune.pp.ua"

from .main import TelegramBridgeModule

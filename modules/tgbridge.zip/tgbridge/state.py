import asyncio
from typing import Any

from pydantic import ValidationError

from .models import DEFAULT_ACCOUNT_ALIAS, DialogBinding, PendingLogin


class BridgeStateStore:
    def __init__(
        self,
        config: Any,
        logger: Any,
    ):
        self._config = config
        self._logger = logger
        self._bindings: dict[str, DialogBinding] = {}
        self._room_index: dict[str, str] = {}
        self._spaces: dict[str, str] = {}
        self._pending_logins: dict[str, PendingLogin] = {}
        self._relations: dict[str, Any] = {}
        self._save_lock = asyncio.Lock()

    async def _get(self, key: str, default: Any):
        return self._config.get(key, default)

    async def _set(self, key: str, value: Any):
        if hasattr(self._config, "set_async"):
            ok = await self._config.set_async(key, value)
        else:
            ok = self._config.set(key, value)

        if not ok:
            raise RuntimeError(f"failed to persist tgbridge state key '{key}'")

    async def load(self):
        raw_bindings = await self._get("bridge_bindings", {})
        raw_spaces = await self._get("bridge_spaces", {})
        raw_pending_logins = await self._get("pending_logins", {})
        raw_relations = await self._get("message_relations", {})

        self._bindings = {}
        if isinstance(raw_bindings, dict):
            for key, payload in raw_bindings.items():
                try:
                    self._bindings[key] = DialogBinding.model_validate(payload)
                except ValidationError as exc:
                    self._logger.warning(f"[TGBridge] Skip invalid binding '{key}': {exc}")

        self._spaces = raw_spaces if isinstance(raw_spaces, dict) else {}
        self._pending_logins = {}
        if isinstance(raw_pending_logins, dict):
            for alias, payload in raw_pending_logins.items():
                try:
                    self._pending_logins[alias] = PendingLogin.model_validate(payload)
                except ValidationError as exc:
                    self._logger.warning(f"[TGBridge] Skip invalid pending login '{alias}': {exc}")

        self._relations = raw_relations if isinstance(raw_relations, dict) else {}
        self._rebuild_room_index()

    def _rebuild_room_index(self):
        self._room_index = {binding.room_id: key for key, binding in self._bindings.items()}

    async def _save_bindings(self):
        payload = {key: binding.model_dump() for key, binding in self._bindings.items()}
        await self._set("bridge_bindings", payload)

    async def _save_spaces(self):
        await self._set("bridge_spaces", self._spaces)

    async def _save_pending_logins(self):
        payload = {alias: login.model_dump() for alias, login in self._pending_logins.items()}
        await self._set("pending_logins", payload)

    def get_relations(self) -> dict[str, Any]:
        return self._relations

    async def save_relations(self, payload: dict[str, Any]):
        async with self._save_lock:
            self._relations = payload
            await self._set("message_relations", payload)

    def get_binding(self, account_alias: str, peer_id: int) -> DialogBinding | None:
        return self._bindings.get(f"{account_alias}:{peer_id}")

    def get_binding_by_room(self, room_id: str) -> DialogBinding | None:
        binding_key = self._room_index.get(room_id)
        return self._bindings.get(binding_key) if binding_key else None

    def get_space(self, account_alias: str) -> str | None:
        return self._spaces.get(account_alias)

    def list_bindings_for_account(self, account_alias: str) -> list[DialogBinding]:
        return [binding for binding in self._bindings.values() if binding.account_alias == account_alias]

    async def upsert_binding(self, binding: DialogBinding):
        self._bindings[binding.key] = binding
        self._rebuild_room_index()
        await self._save_bindings()

    async def set_space(self, account_alias: str, space_id: str):
        self._spaces[account_alias] = space_id
        await self._save_spaces()

    def get_pending_login(self) -> PendingLogin | None:
        return self._pending_logins.get(DEFAULT_ACCOUNT_ALIAS)

    async def set_pending_login(self, login: PendingLogin):
        self._pending_logins[DEFAULT_ACCOUNT_ALIAS] = login
        await self._save_pending_logins()

    async def clear_pending_login(self):
        if DEFAULT_ACCOUNT_ALIAS in self._pending_logins:
            self._pending_logins.pop(DEFAULT_ACCOUNT_ALIAS, None)
            await self._save_pending_logins()

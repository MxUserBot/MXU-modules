from __future__ import annotations

import asyncio
import mimetypes
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .main import TelegramBridgeModule

from mautrix.types import MessageEvent, MessageType
from telethon import events

from ... import utils
from .dedupe import BridgeDeduplicator, BridgeRelationIndex
from .matrix import MatrixBridgeService
from .models import (
    BootstrapSummary,
    BridgeDialog,
    MatrixOutboundMessage,
    SyncSummary,
)
from .state import BridgeStateStore
from .telegram import TelegramBridgeService


class BridgeCoordinator:
    def __init__(
        self,
        module: TelegramBridgeModule,
        logger: Any,
        matrix_service: MatrixBridgeService,
        telegram_service: TelegramBridgeService,
        state: BridgeStateStore,
        dedupe: BridgeDeduplicator,
        relations: BridgeRelationIndex,
    ):
        self.module = module
        self.logger = logger
        self.matrix = matrix_service
        self.telegram = telegram_service
        self.state = state
        self.dedupe = dedupe
        self.relations = relations
        self._sync_lock = asyncio.Lock()
        self._media_semaphore = asyncio.Semaphore(3)

    async def _remember_relation(self, binding_key: str, telegram_message_id: int, matrix_event_id: str):
        self.relations.remember(binding_key, telegram_message_id, matrix_event_id)
        await self.state.save_relations(self.relations.to_dict())

    def _is_telegram_edit(self, event: Any) -> bool:
        return bool(events and isinstance(event, events.MessageEdited.Event))

    async def sync_dialogs(self, account_alias: str | None = None) -> list[SyncSummary]:
        summaries: list[SyncSummary] = []

        async with self._sync_lock:
            for runtime in self.telegram.list_runtimes(account_alias):
                summary = SyncSummary(account_alias=runtime.config.alias)
                await self.matrix.ensure_space(runtime.config)

                self.logger.info(f"[TGBridge] Syncing dialogs for '{runtime.config.alias}'...")

                async for dialog in runtime.client.iter_dialogs(limit=self.module.config["dialog_scan_limit"]):
                    descriptor = await self.telegram.describe_dialog(runtime, dialog)
                    if descriptor is None:
                        summary.skipped += 1
                        continue

                    try:
                        _, created = await self.matrix.ensure_room(runtime.config, descriptor)
                        if created:
                            summary.created += 1
                            base_delay = self.module.config["room_creation_delay"]
                            batch_size = self.module.config.get("space_attach_batch_size", 3)
                            if base_delay > 0:
                                progressive = base_delay * (1.25 ** (summary.created - 1))
                                wait = min(progressive, 120)
                                self.logger.info(
                                    f"[TGBridge] Room #{summary.created}, waiting {wait:.1f}s "
                                    f"(progressive delay)"
                                )
                                await asyncio.sleep(wait)
                            if summary.created % batch_size == 0:
                                rest = 30
                                self.logger.info(
                                    f"[TGBridge] Batch of {batch_size} rooms created, resting {rest}s"
                                )
                                await asyncio.sleep(rest)
                        else:
                            summary.existing += 1
                    except Exception as exc:
                        summary.failed += 1
                        self.logger.error(
                            f"[TGBridge] Failed to sync '{descriptor.title}' via '{runtime.config.alias}': {exc}"
                        )

                summaries.append(summary)

        return summaries

    async def bootstrap_accounts(self, account_alias: str | None = None) -> list[BootstrapSummary]:
        summaries: list[BootstrapSummary] = []
        invite_targets = [target.strip() for target in self.module.config["invite_targets"] if target.strip()]

        async with self._sync_lock:
            for runtime in self.telegram.list_runtimes(account_alias):
                await self.matrix.ensure_space(runtime.config)
                summary = await self.telegram.bootstrap_account(runtime.config.alias, invite_targets)
                summaries.append(summary)

        return summaries

    async def handle_telegram_event(self, account_alias: str, event: Any):
        runtime = self.telegram.get_runtime(account_alias)
        if runtime is None:
            return

        descriptor = await self.telegram.describe_event(runtime, event)
        if descriptor is None:
            return

        self.logger.info(
            f"[TGBridge] TG\u2192Matrix: '{descriptor.title}' "
            f"(msg#{getattr(event, 'id', '?')}) "
            f"{'out' if getattr(event, 'out', False) else 'in'}"
        )

        binding, _ = await self.matrix.ensure_room(runtime.config, descriptor)
        message_id = getattr(event, "id", None)

        if getattr(event, "out", False):
            if message_id is not None and self.dedupe.consume_telegram(account_alias, descriptor.peer_id, int(message_id)):
                return

            if not self.module.config["bridge_own_telegram_messages"]:
                return

        async with self._media_semaphore:
            bridge_message = await self.telegram.render_event_message(runtime, event)
            if bridge_message is None:
                return

            if self._is_telegram_edit(event) and message_id is not None:
                if bridge_message.has_media:
                    return
                original_event_id = self.relations.get_matrix_event(binding.key, int(message_id))
                if original_event_id:
                    matrix_event_id = await self.matrix.edit_bridge_message(
                        binding,
                        bridge_message,
                        original_event_id,
                    )
                    self.dedupe.remember_matrix(matrix_event_id)
                    return

            reply_event_id = self.relations.get_matrix_event(binding.key, bridge_message.reply_to_telegram_id)
            matrix_event_id = await self.matrix.send_bridge_message(binding, bridge_message, reply_event_id=reply_event_id)

            if matrix_event_id and message_id is not None:
                self.dedupe.remember_matrix(matrix_event_id)
                await self._remember_relation(binding.key, int(message_id), matrix_event_id)

            if self.module.config["message_relay_delay"] > 0:
                await asyncio.sleep(self.module.config["message_relay_delay"])

    async def handle_matrix_message(self, mx: Any, event: MessageEvent):
        if not self.module.config["allow_matrix_to_telegram"]:
            return

        binding = self.state.get_binding_by_room(str(event.room_id))
        if binding is None:
            return

        if str(event.sender) != str(mx.client.mxid):
            return

        if self.dedupe.consume_matrix(str(event.event_id)):
            return

        edit_event_id = self._extract_matrix_edit_event_id(event)
        if edit_event_id:
            telegram_message_id = self.relations.get_telegram_message(binding.key, edit_event_id)
            if telegram_message_id is None:
                return

            text = await self._extract_matrix_body(mx, event, prefer_new_content=True)
            if not text:
                return

            await self.telegram.edit_text(
                binding.account_alias,
                binding.peer_id,
                telegram_message_id,
                text,
            )
            self.dedupe.remember_telegram(binding.account_alias, binding.peer_id, telegram_message_id)
            return

        outbound = await self._extract_matrix_outbound(mx, event)
        if not outbound.text and not outbound.has_media:
            return

        reply_to_event = self._extract_matrix_reply_event_id(event)
        outbound.reply_to_telegram_id = self.relations.get_telegram_message(binding.key, reply_to_event)

        sent_message = await self.telegram.send_matrix_message(binding.account_alias, binding.peer_id, outbound)

        telegram_message_id = getattr(sent_message, "id", None)
        if telegram_message_id is not None:
            self.dedupe.remember_telegram(binding.account_alias, binding.peer_id, int(telegram_message_id))
            await self._remember_relation(binding.key, int(telegram_message_id), str(event.event_id))

        await asyncio.sleep(self.module.config["message_relay_delay"])

    def _extract_matrix_edit_event_id(self, event: MessageEvent) -> str | None:
        content = getattr(event, "content", None)
        if content is None:
            return None

        get_edit = getattr(content, "get_edit", None)
        if callable(get_edit):
            try:
                edit_id = get_edit()
                if edit_id:
                    return str(edit_id)
            except Exception:
                return None

        relates_to = getattr(content, "relates_to", None) or getattr(content, "_relates_to", None)
        rel_type = getattr(relates_to, "rel_type", None)
        event_id = getattr(relates_to, "event_id", None)
        return str(event_id) if str(rel_type) == "m.replace" and event_id else None

    async def _extract_matrix_body(self, mx: Any, event: MessageEvent, prefer_new_content: bool = False) -> str:
        content = getattr(event, "content", None)
        if content is None:
            return ""

        if prefer_new_content:
            new_content = None
            if hasattr(content, "get"):
                try:
                    new_content = content.get("m.new_content")
                except Exception:
                    new_content = None
            new_content = new_content or getattr(content, "new_content", None) or getattr(content, "_new_content", None)
            if isinstance(new_content, dict):
                body = (new_content.get("body") or "").strip()
                if body:
                    return self._strip_matrix_edit_fallback(body)
            elif new_content is not None:
                body = (getattr(new_content, "body", None) or "").strip()
                if body:
                    return self._strip_matrix_edit_fallback(body)

        body = (getattr(content, "body", None) or "").strip()
        return body

    def _strip_matrix_edit_fallback(self, text: str) -> str:
        idx = text.rfind("\n\n")
        return text[:idx].strip() if idx > 0 else text

    async def _extract_matrix_outbound(self, mx: Any, event: MessageEvent) -> MatrixOutboundMessage:
        content = getattr(event, "content", None)
        text = await self._extract_matrix_body(mx, event)

        msgtype = str(getattr(content, "msgtype", ""))
        has_media = msgtype != str(MessageType.TEXT)

        if not has_media:
            return MatrixOutboundMessage(text=text)

        outbound = MatrixOutboundMessage(text=text)
        media_kind = self._matrix_media_kind(msgtype)
        outbound.msgtype = msgtype

        try:
            if getattr(content, "file", None):
                ciphertext = await mx.client.download_media(content.file.url)
                from mautrix.crypto.attachments import decrypt_attachment
                data = decrypt_attachment(
                    ciphertext, content.file.key.key,
                    content.file.hashes.get("sha256"), content.file.iv
                )
            else:
                data = await mx.client.download_media(getattr(content, "url", None))

            mxc = getattr(content, "url", None)
            if mxc:
                outbound.mimetype = getattr(content, "mimetype", None) or (getattr(content.file, "mimetype", None) if getattr(content, "file", None) else None)
                outbound.filename = getattr(content, "body", "matrix_media")
                outbound.mimetype = outbound.mimetype or mimetypes.guess_type(outbound.filename)[0]
            elif getattr(content, "file", None):
                outbound.mimetype = getattr(content.file, "mimetype", None)
                outbound.filename = getattr(content, "body", "matrix_media")

            outbound.media_bytes = data
        except Exception as exc:
            self.logger.warning(f"[TGBridge] Failed to download Matrix media: {exc}")

        return outbound

    def _matrix_media_kind(self, msgtype: str) -> str:
        if msgtype == str(MessageType.IMAGE):
            return "image"
        elif msgtype == str(MessageType.VIDEO):
            return "video"
        elif msgtype == str(MessageType.AUDIO):
            return "audio"
        elif msgtype == str(MessageType.STICKER):
            return "sticker"
        return "document"

    def _extract_matrix_reply_event_id(self, event: MessageEvent) -> str | None:
        content = getattr(event, "content", None)
        if content is None:
            return None

        relates_to = getattr(content, "relates_to", None) or getattr(content, "_relates_to", None)
        rel_type = getattr(relates_to, "rel_type", None)

        if str(rel_type) == "m.in_reply_to":
            in_reply_to = getattr(relates_to, "in_reply_to", None)
            if in_reply_to is not None:
                return str(getattr(in_reply_to, "event_id", None) or in_reply_to.get("event_id"))

        return None

from __future__ import annotations

import io
import mimetypes
from pathlib import Path
from typing import TYPE_CHECKING, Any, Awaitable, Callable

if TYPE_CHECKING:
    from .main import TelegramBridgeModule

from mautrix.types import MessageType
from telethon import TelegramClient, events, utils as tg_utils
from telethon.errors import SessionPasswordNeededError
from telethon.sessions import StringSession
from telethon.tl.functions.channels import InviteToChannelRequest
from telethon.tl.functions.messages import AddChatUserRequest

from ... import utils
from .models import (
    BootstrapSummary,
    BridgeDialog,
    BridgeMessage,
    MatrixOutboundMessage,
    PendingLogin,
    TelegramAccountConfig,
    TelegramAccountRuntime,
)
from .state import BridgeStateStore


class TelegramBridgeService:
    def __init__(
        self,
        module: TelegramBridgeModule,
        logger: Any,
        event_listener: Callable[[str, Any], Awaitable[None]],
    ):
        self.module = module
        self.logger = logger
        self.event_listener = event_listener
        self.runtimes: dict[str, TelegramAccountRuntime] = {}
        self.start_errors: dict[str, str] = {}

    async def stop(self):
        for runtime in self.runtimes.values():
            try:
                await runtime.client.disconnect()
            except Exception:
                pass

        self.runtimes.clear()
        self.start_errors.clear()

    async def start(self, accounts: list[TelegramAccountConfig]):
        await self.stop()

        for account in accounts:
            if not account.enabled:
                self.start_errors[account.alias] = "disabled"
                continue

            try:
                runtime = await self._start_account(account)
                self.runtimes[account.alias] = runtime
            except Exception as exc:
                self.start_errors[account.alias] = str(exc)
                self.logger.error(f"[TGBridge] Failed to start Telegram account '{account.alias}': {exc}")

    def list_runtimes(self, alias: str | None = None) -> list[TelegramAccountRuntime]:
        if alias:
            runtime = self.runtimes.get(alias.lower())
            return [runtime] if runtime else []
        return list(self.runtimes.values())

    def get_runtime(self, alias: str) -> TelegramAccountRuntime | None:
        return self.runtimes.get(alias.lower())

    def _session_source(self, account: TelegramAccountConfig) -> Any:
        if account.session:
            return StringSession(account.session)

        session_path = Path(account.session_name or f".tgbridge_sessions/{account.alias}")
        if not session_path.is_absolute():
            session_path = Path.cwd() / session_path
        session_path.parent.mkdir(parents=True, exist_ok=True)
        return str(session_path)

    async def _start_account(self, account: TelegramAccountConfig) -> TelegramAccountRuntime:
        client = TelegramClient(
            self._session_source(account),
            int(account.api_id),
            account.api_hash,
            sequential_updates=False,
        )

        await client.connect()

        if not await client.is_user_authorized():
            await client.disconnect()
            raise RuntimeError("telegram account is not authorized")

        me = await client.get_me()
        runtime = TelegramAccountRuntime(
            config=account,
            client=client,
            me_id=getattr(me, "id", None),
            me_display=self._entity_title(me, fallback=account.title or account.alias),
        )

        async def handler(event, account_alias: str = account.alias):
            await self.event_listener(account_alias, event)

        client.add_event_handler(handler, events.NewMessage())
        client.add_event_handler(handler, events.MessageEdited())
        return runtime

    def _resolve_peer_id(self, entity: Any, fallback: int | None = None) -> int:
        if tg_utils is not None and entity is not None:
            try:
                return int(tg_utils.get_peer_id(entity))
            except Exception:
                pass

        for attr in ("chat_id", "user_id", "channel_id", "id"):
            value = getattr(entity, attr, None)
            if value is not None:
                return int(value)

        if fallback is not None:
            return int(fallback)

        raise ValueError("unable to resolve peer id")

    def _peer_type(self, entity: Any, source: Any = None) -> str:
        if source is not None and getattr(source, "is_private", False):
            return "user"

        if getattr(entity, "broadcast", False):
            return "channel"

        if getattr(entity, "megagroup", False):
            return "megagroup"

        class_name = entity.__class__.__name__.lower() if entity is not None else ""
        if "user" in class_name:
            return "user"
        if "channel" in class_name:
            return "channel"
        return "chat"

    def _entity_title(self, entity: Any, fallback: str = "Telegram") -> str:
        if entity is None:
            return fallback

        title = getattr(entity, "title", None)
        if title:
            return str(title)

        first = getattr(entity, "first_name", "") or ""
        last = getattr(entity, "last_name", "") or ""
        full_name = f"{first} {last}".strip()
        if full_name:
            return full_name

        username = getattr(entity, "username", None)
        if username:
            return f"@{username}"

        entity_id = getattr(entity, "id", None)
        if entity_id is not None:
            return f"{fallback} {entity_id}"

        return fallback

    def _is_dialog_supported(self, account: TelegramAccountConfig, peer_type: str, entity: Any) -> bool:
        if peer_type == "user":
            if getattr(entity, "bot", False):
                return self.module.config["bridge_bot_dialogs"]
            return self.module.config["sync_private_chats"] and account.bridge_private

        if peer_type in {"chat", "megagroup"}:
            return False

        if peer_type == "channel":
            if getattr(entity, "megagroup", False):
                return False
            return self.module.config["sync_channels"] and account.bridge_channels

        return False

    async def describe_dialog(self, runtime: TelegramAccountRuntime, dialog: Any) -> BridgeDialog | None:
        entity = getattr(dialog, "entity", None)
        if entity is None:
            return None

        peer_type = "user" if getattr(dialog, "is_user", False) else self._peer_type(entity, dialog)
        if not self._is_dialog_supported(runtime.config, peer_type, entity):
            return None

        title = getattr(dialog, "name", None) or self._entity_title(entity)
        return BridgeDialog(
            account_alias=runtime.config.alias,
            peer_id=self._resolve_peer_id(entity),
            peer_type=peer_type,
            title=title,
            is_direct=peer_type == "user",
            entity=entity,
        )

    async def describe_event(self, runtime: TelegramAccountRuntime, event: Any) -> BridgeDialog | None:
        chat = None
        entity = None

        try:
            chat = await event.get_chat()
        except Exception:
            chat = None

        if getattr(event, "is_private", False):
            entity = chat
            if entity is None:
                try:
                    entity = await event.get_sender()
                except Exception:
                    entity = None
        else:
            entity = chat

        if entity is None:
            return None

        peer_type = self._peer_type(entity, event)
        if not self._is_dialog_supported(runtime.config, peer_type, entity):
            return None

        peer_id = self._resolve_peer_id(entity, fallback=getattr(event, "chat_id", None))
        title = self._entity_title(entity, fallback=f"{peer_type} {peer_id}")
        return BridgeDialog(
            account_alias=runtime.config.alias,
            peer_id=peer_id,
            peer_type=peer_type,
            title=title,
            is_direct=peer_type == "user",
            entity=entity,
        )

    def _media_kind(self, message: Any) -> str | None:
        if message is None or getattr(message, "media", None) is None:
            return None

        if getattr(message, "sticker", False):
            return "sticker"
        if getattr(message, "voice", False):
            return "voice"
        if getattr(message, "video", False) or getattr(message, "gif", False):
            return "video"
        if getattr(message, "photo", False):
            return "image"
        if getattr(message, "audio", False):
            return "audio"
        return "document"

    def _media_fallback(self, media_kind: str | None) -> str:
        return {
            "sticker": "[Sticker]",
            "voice": "[Voice]",
            "video": "[Video]",
            "image": "[Photo]",
            "audio": "[Audio]",
            "document": "[File]",
        }.get(media_kind or "", "")

    async def _download_event_media(self, event: Any, client: Any = None) -> tuple[bytes | None, dict[str, Any]]:
        message = getattr(event, "message", None)
        media_kind = self._media_kind(message)
        if not media_kind:
            return None, {"media_kind": None}

        msg_id = getattr(event, "id", "?")
        self.logger.info(f"[TGBridge] Downloading {media_kind} (msg#{msg_id})...")

        media_bytes = None
        download_errors: list[str] = []

        for attempt in range(2):
            try:
                if attempt == 0:
                    media_bytes = await message.download_media(file=bytes)
                elif client is not None:
                    media_obj = getattr(message, "media", None)
                    if media_obj:
                        media_bytes = await client.download_media(media_obj, file=bytes)
                if media_bytes:
                    break
            except Exception as exc:
                download_errors.append(str(exc))
                media_bytes = None

        if not media_bytes:
            if download_errors:
                self.logger.warning(f"[TGBridge] Media download failed ({', '.join(download_errors)})")
            return None, {"media_kind": media_kind}

        file_meta = getattr(message, "file", None)
        filename = (
            getattr(file_meta, "name", None)
            or getattr(file_meta, "title", None)
            or f"telegram_{getattr(message, 'id', 'media')}"
        )
        mimetype = getattr(file_meta, "mime_type", None) or mimetypes.guess_type(filename)[0]

        if not mimetype:
            mimetype = {
                "sticker": "image/webp",
                "image": "image/jpeg",
                "video": "video/mp4",
                "voice": "audio/ogg",
                "audio": "audio/mpeg",
            }.get(media_kind, "application/octet-stream")

        if "." not in filename:
            ext = mimetypes.guess_extension(mimetype or "") or ""
            filename = f"{filename}{ext}"

        if media_kind == "sticker" and mimetype not in {"image/webp", "image/png", "image/jpeg"}:
            media_kind = "document"

        size_kb = len(media_bytes) / 1024
        self.logger.info(f"[TGBridge] Downloaded {media_kind} '{filename}' ({size_kb:.0f} KB, msg#{msg_id})")

        return media_bytes, {
            "media_kind": media_kind,
            "mimetype": mimetype,
            "filename": filename,
            "size": getattr(file_meta, "size", None) or len(media_bytes),
            "width": getattr(file_meta, "width", None),
            "height": getattr(file_meta, "height", None),
            "duration": int(getattr(file_meta, "duration", 0) * 1000) if getattr(file_meta, "duration", None) else None,
            "voice_note": media_kind == "voice",
        }

    async def render_event_message(self, runtime: TelegramAccountRuntime, event: Any) -> BridgeMessage | None:
        body = (getattr(event, "raw_text", None) or getattr(getattr(event, "message", None), "message", None) or "").strip()
        media_bytes, media_meta = await self._download_event_media(event, client=runtime.client)
        media_tag = self._media_fallback(media_meta.get("media_kind"))

        if media_tag and body:
            body = f"{media_tag}\n{body}"
        elif media_tag:
            body = media_tag

        if not body and not media_bytes:
            return None

        sender_title = runtime.me_display
        if not getattr(event, "out", False):
            sender = None
            try:
                sender = await event.get_sender()
            except Exception:
                sender = None
            sender_title = self._entity_title(sender, fallback="Telegram")

        plain_prefix = f"[{sender_title}]"
        html_prefix = f"<b>{utils.escape_html(sender_title)}</b>"

        html_body = utils.escape_html(body).replace("\n", "<br>")
        reply_to_id = getattr(event, "reply_to_msg_id", None) or getattr(getattr(event, "message", None), "reply_to_msg_id", None)

        return BridgeMessage(
            plain_text=f"{plain_prefix} {body}",
            html_text=f"{html_prefix}: {html_body}",
            reply_to_telegram_id=int(reply_to_id) if reply_to_id else None,
            media_kind=media_meta.get("media_kind"),
            media_bytes=media_bytes,
            mimetype=media_meta.get("mimetype"),
            filename=media_meta.get("filename"),
            size=media_meta.get("size"),
            width=media_meta.get("width"),
            height=media_meta.get("height"),
            duration=media_meta.get("duration"),
            voice_note=bool(media_meta.get("voice_note")),
        )

    async def send_matrix_message(
        self,
        account_alias: str,
        peer_id: int,
        outbound: MatrixOutboundMessage,
    ) -> Any:
        runtime = self.get_runtime(account_alias)
        if runtime is None:
            raise RuntimeError(f"telegram runtime '{account_alias}' is not active")

        input_entity = await runtime.client.get_input_entity(peer_id)
        kwargs = {"reply_to": outbound.reply_to_telegram_id} if outbound.reply_to_telegram_id else {}

        if not outbound.has_media:
            return await runtime.client.send_message(input_entity, outbound.text, **kwargs)

        file_obj = io.BytesIO(outbound.media_bytes or b"")
        file_obj.name = outbound.filename or "matrix_media"
        return await runtime.client.send_file(
            input_entity,
            file_obj,
            caption=outbound.text or None,
            mime_type=outbound.mimetype,
            force_document=self._force_document(outbound),
            voice_note=outbound.voice_note,
            **kwargs,
        )

    async def edit_text(self, account_alias: str, peer_id: int, message_id: int, text: str) -> Any:
        runtime = self.get_runtime(account_alias)
        if runtime is None:
            raise RuntimeError(f"telegram runtime '{account_alias}' is not active")

        input_entity = await runtime.client.get_input_entity(peer_id)
        return await runtime.client.edit_message(input_entity, message_id, text=text)

    def _force_document(self, outbound: MatrixOutboundMessage) -> bool:
        msgtype = str(outbound.msgtype or "")
        mimetype = outbound.mimetype or ""
        if msgtype in {str(MessageType.IMAGE), str(MessageType.VIDEO), str(MessageType.AUDIO), str(MessageType.STICKER)}:
            return False
        return not mimetype.startswith(("image/", "video/", "audio/"))

    async def bootstrap_account(self, account_alias: str, extra_targets: list[str]) -> BootstrapSummary:
        runtime = self.get_runtime(account_alias)
        if runtime is None:
            raise RuntimeError(f"telegram runtime '{account_alias}' is not active")

        targets = list(dict.fromkeys(runtime.config.invite_targets + extra_targets))
        summary = BootstrapSummary(account_alias=account_alias)

        if not targets:
            return summary

        resolved_targets: list[Any] = []
        for raw_target in targets:
            try:
                resolved_targets.append(await runtime.client.get_input_entity(raw_target))
            except Exception as exc:
                summary.failed += 1
                self.logger.warning(f"[TGBridge] Failed to resolve invite target '{raw_target}' for '{account_alias}': {exc}")

        if not resolved_targets:
            return summary

        async for dialog in runtime.client.iter_dialogs(limit=self.module.config["dialog_scan_limit"]):
            descriptor = await self.describe_dialog(runtime, dialog)
            if descriptor is None or descriptor.peer_type not in {"chat", "megagroup", "channel"}:
                continue

            for target in resolved_targets:
                summary.attempted += 1
                try:
                    await self._invite_to_dialog(runtime.client, dialog.entity, target)
                    summary.invited += 1
                except Exception as exc:
                    err = str(exc).lower()
                    if "already" in err or "participant" in err or "user is already" in err:
                        summary.skipped += 1
                    else:
                        summary.failed += 1
                        self.logger.warning(
                            f"[TGBridge] Invite failed in '{descriptor.title}' via '{account_alias}': {exc}"
                        )

        return summary

    async def _invite_to_dialog(self, client: Any, dialog_entity: Any, target: Any):
        if getattr(dialog_entity, "megagroup", False) or dialog_entity.__class__.__name__.lower().endswith("channel"):
            await client(InviteToChannelRequest(dialog_entity, [target]))
            return

        await client(AddChatUserRequest(dialog_entity.id, target, fwd_limit=10))


class TelegramAuthService:
    def __init__(self, module: TelegramBridgeModule, state: BridgeStateStore, logger: Any):
        self.module = module
        self.state = state
        self.logger = logger

    def _session_source(self, account: TelegramAccountConfig, session_override: str | None = None) -> StringSession:
        s = session_override or account.session
        if s:
            return StringSession(s)
        return StringSession()

    async def _build_client(self, account: TelegramAccountConfig, session_override: str | None = None) -> Any:
        client = TelegramClient(
            self._session_source(account, session_override),
            int(account.api_id),
            account.api_hash,
            sequential_updates=True,
        )
        await client.connect()
        return client

    def _extract_session(self, client: Any) -> str | None:
        try:
            return client.session.save()
        except Exception:
            return None

    async def send_code(self, account: TelegramAccountConfig, phone_number: str):
        client = await self._build_client(account)
        try:
            if await client.is_user_authorized():
                return {"authorized": True, "session": self._extract_session(client)}

            sent = await client.send_code_request(phone_number)
            session_str = self._extract_session(client) or ""
            await self.state.set_pending_login(
                PendingLogin(
                    phone_number=phone_number,
                    phone_code_hash=sent.phone_code_hash,
                    session=session_str,
                )
            )
            return {"authorized": False, "phone_number": phone_number}
        finally:
            await client.disconnect()

    async def sign_in(self, account: TelegramAccountConfig, code: str):
        pending = self.state.get_pending_login()
        if pending is None:
            raise RuntimeError("no pending login; run tglogin first")

        client = await self._build_client(account, session_override=pending.session or None)
        try:
            result = await client.sign_in(
                phone=pending.phone_number,
                code=code,
                phone_code_hash=pending.phone_code_hash,
            )

            session = self._extract_session(client)
            needs_password = result is None
            if not needs_password:
                await self.state.clear_pending_login()

            return {"password_required": needs_password, "session": session}
        except SessionPasswordNeededError:
            return {"password_required": True, "session": None}
        finally:
            await client.disconnect()

    async def sign_in_with_password(self, account: TelegramAccountConfig, password: str):
        pending = self.state.get_pending_login()
        if pending is None:
            raise RuntimeError("no pending login; run tglogin first")

        client = await self._build_client(account, session_override=pending.session or None)
        try:
            await client.sign_in(password=password)
            session = self._extract_session(client)
            await self.state.clear_pending_login()
            return {"session": session}
        finally:
            await client.disconnect()

from __future__ import annotations

import asyncio
import mimetypes
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .main import TelegramBridgeModule
    from .state import BridgeStateStore

from mautrix.errors.request import MLimitExceeded
from mautrix.types import EventType, Format, MessageType, RoomDirectoryVisibility, TextMessageEventContent

from ... import utils
from ...core.utils.media_types import Audio, Document, Image, Sticker, Video
from .models import BridgeDialog, BridgeMessage, DialogBinding, TelegramAccountConfig


class MatrixBridgeService:
    def __init__(self, mx: Any, module: TelegramBridgeModule, state: BridgeStateStore, logger: Any):
        self.mx = mx
        self.module = module
        self.state = state
        self.logger = logger
        self._space_attach_lock = asyncio.Lock()
        self._last_space_attach = 0.0
        self._attach_batch_count = 0

    async def _retry_on_429(self, coro_factory, max_retries=10):
        for attempt in range(max_retries):
            try:
                return await coro_factory()
            except MLimitExceeded as exc:
                if attempt == max_retries - 1:
                    raise
                retry_after = getattr(exc, "retry_after_ms", 5000) / 1000
                wait = min(max(retry_after, 1.0) * (1.5 ** attempt), 120)
                self.logger.warning(f"[TGBridge] Rate limited, retrying in {wait:.1f}s "
                                    f"(attempt {attempt + 1}/{max_retries})")
                await asyncio.sleep(wait)

    def _safe_format(self, template: str, fallback: str, **kwargs) -> str:
        try:
            return template.format(**kwargs)
        except Exception:
            return fallback

    def _room_name(self, account: TelegramAccountConfig, dialog: BridgeDialog) -> str:
        fallback = f"TG | {account.title} | {dialog.title}"
        return self._safe_format(
            self.module.config["room_name_template"],
            fallback,
            account=account.title,
            title=dialog.title,
            peer_type=dialog.peer_type,
        )

    def _space_name(self, account: TelegramAccountConfig) -> str:
        fallback = f"Telegram | {account.title}"
        return self._safe_format(
            self.module.config["space_name_template"],
            fallback,
            account=account.title,
        )

    def _room_topic(self, account: TelegramAccountConfig, dialog: BridgeDialog) -> str:
        return (
            f"Telegram bridge room\n"
            f"Account: {account.title}\n"
            f"Dialog: {dialog.title}\n"
            f"Type: {dialog.peer_type}"
        )

    async def _send_state(self, room_id: str, event_type: str, content: dict):
        await self._retry_on_429(
            lambda: self.mx.client.send_state_event(
                room_id=room_id,
                event_type=event_type,
                state_key="",
                content=content,
            )
        )

    async def _set_room_meta(self, room_id: str, name: str, topic: str):
        try:
            await self._send_state(room_id, "m.room.name", {"name": name})
        except Exception:
            pass

        try:
            await self._send_state(room_id, "m.room.topic", {"topic": topic})
        except Exception:
            pass

    async def _set_room_encryption(self, room_id: str):
        if not self.module.config.get("encrypt_rooms"):
            return
        try:
            await self._send_state(room_id, "m.room.encryption", {"algorithm": "m.megolm.v1.aes-sha2"})
        except Exception as exc:
            self.logger.warning(f"[TGBridge] Failed to enable encryption in {room_id}: {exc}")

    async def _attach_to_space(self, space_id: str, room_id: str):
        mxid = getattr(self.mx.client, "mxid", "")
        via_domain = mxid.split(":", 1)[1] if ":" in mxid else "matrix.org"

        async with self._space_attach_lock:
            elapsed = time.monotonic() - self._last_space_attach
            if elapsed < 2.0:
                await asyncio.sleep(2.0 - elapsed)

            batch_size = self.module.config.get("space_attach_batch_size", 3)
            batch_delay = self.module.config.get("space_attach_batch_delay", 10)

            if self._attach_batch_count >= batch_size:
                self.logger.info(
                    f"[TGBridge] Batch limit ({batch_size}), resting {batch_delay}s"
                )
                await asyncio.sleep(batch_delay)
                self._attach_batch_count = 0

            self.logger.debug(f"[TGBridge] Attaching room {room_id} to space {space_id}")

            try:
                await self._retry_on_429(
                    lambda: self.mx.client.send_state_event(
                        room_id=space_id,
                        event_type="m.space.child",
                        state_key=room_id,
                        content={"via": [via_domain]},
                    ),
                    max_retries=10,
                )
                self._last_space_attach = time.monotonic()
                self._attach_batch_count += 1
            except Exception as exc:
                self.logger.warning(f"[TGBridge] Failed to attach room {room_id} to space {space_id}: {exc}")

    async def ensure_space(self, account: TelegramAccountConfig) -> str | None:
        existing = self.state.get_space(account.alias)
        if existing:
            return existing

        space_id = await self._retry_on_429(
            lambda: self.mx.client.create_room(
                name=self._space_name(account),
                visibility=RoomDirectoryVisibility.PRIVATE,
                creation_content={"type": "m.space"},
            )
        )

        space_id = str(space_id)
        await self.state.set_space(account.alias, space_id)
        await self._set_room_meta(space_id, self._space_name(account), f"Bridge space for Telegram account {account.title}")
        return space_id

    async def ensure_room(self, account: TelegramAccountConfig, dialog: BridgeDialog) -> tuple[DialogBinding, bool]:
        existing = self.state.get_binding(account.alias, dialog.peer_id)
        space_id = await self.ensure_space(account)
        room_name = self._room_name(account, dialog)
        room_topic = self._room_topic(account, dialog)

        if existing:
            changed = False
            if existing.title != dialog.title:
                existing.title = dialog.title
                changed = True
            if existing.peer_type != dialog.peer_type:
                existing.peer_type = dialog.peer_type
                changed = True
            if existing.is_direct != dialog.is_direct:
                existing.is_direct = dialog.is_direct
                changed = True
            if space_id and existing.space_id != space_id:
                existing.space_id = space_id
                changed = True

            if changed:
                await self.state.upsert_binding(existing)
                await self._set_room_meta(existing.room_id, room_name, room_topic)
                if space_id:
                    await self._attach_to_space(space_id, existing.room_id)

            await self._set_room_encryption(existing.room_id)

            return existing, False

        room_id = await self._retry_on_429(
            lambda: self.mx.client.create_room(
                name=room_name,
                visibility=RoomDirectoryVisibility.PRIVATE,
                is_direct=dialog.is_direct,
            )
        )

        self.logger.info(
            f"[TGBridge] Created room '{room_name}' ({room_id}) "
            f"for '{dialog.title}' ({dialog.peer_type}:{dialog.peer_id}) "
            f"via account '{account.alias}'"
        )

        binding = DialogBinding(
            account_alias=account.alias,
            peer_id=dialog.peer_id,
            peer_type=dialog.peer_type,
            title=dialog.title,
            room_id=str(room_id),
            space_id=space_id,
            is_direct=dialog.is_direct,
        )

        await self.state.upsert_binding(binding)
        await self._set_room_meta(binding.room_id, room_name, room_topic)
        await self._set_room_encryption(binding.room_id)

        if space_id:
            await self._attach_to_space(space_id, binding.room_id)

        return binding, True

    async def send_bridge_message(
        self,
        binding: DialogBinding,
        bridge_message: BridgeMessage,
        reply_event_id: str | None = None,
    ) -> str:
        if bridge_message.has_media:
            return await self._send_bridge_media(binding, bridge_message)

        content = TextMessageEventContent(
            msgtype=MessageType.TEXT,
            body=bridge_message.plain_text,
            format=Format.HTML,
            formatted_body=bridge_message.html_text,
        )

        if reply_event_id:
            try:
                content.set_reply(reply_event_id)
            except Exception:
                pass

        event_id = await self.mx.client.send_message(binding.room_id, content)
        return str(event_id)

    async def edit_bridge_message(
        self,
        binding: DialogBinding,
        bridge_message: BridgeMessage,
        original_event_id: str,
    ) -> str:
        content = TextMessageEventContent(
            msgtype=MessageType.TEXT,
            body=bridge_message.plain_text,
            format=Format.HTML,
            formatted_body=bridge_message.html_text,
        )
        content.set_edit(original_event_id)
        event_id = await self.mx.client.send_message_event(
            binding.room_id,
            EventType.ROOM_MESSAGE,
            content,
        )
        return str(event_id)

    async def _send_bridge_media(self, binding: DialogBinding, bridge_message: BridgeMessage) -> str:
        text = bridge_message.plain_text
        media_kind = bridge_message.media_kind or "document"
        media_bytes = bridge_message.media_bytes or b""
        filename = bridge_message.filename or f"telegram_{media_kind}"
        mimetype = bridge_message.mimetype or mimetypes.guess_type(filename)[0] or "application/octet-stream"

        size_kb = len(media_bytes) / 1024
        self.logger.info(f"[TGBridge] Uploading {media_kind} '{filename}' ({size_kb:.0f} KB) to {binding.room_id}")

        if media_kind == "sticker":
            media = Sticker(
                url=media_bytes,
                caption=text,
                filename=filename,
                mimetype=mimetype,
                size=bridge_message.size,
                w=bridge_message.width,
                h=bridge_message.height,
            )
            return await utils.send_sticker(self.mx, binding.room_id, media, text=text, html=False)

        if media_kind == "image":
            media = Image(
                url=media_bytes,
                caption=text,
                filename=filename,
                mimetype=mimetype,
                size=bridge_message.size,
                w=bridge_message.width,
                h=bridge_message.height,
            )
            event_id = await utils.send_image(self.mx, binding.room_id, media, text=text, html=False)

        elif media_kind == "video":
            media = Video(
                url=media_bytes,
                caption=text,
                filename=filename,
                mimetype=mimetype,
                size=bridge_message.size,
                w=bridge_message.width,
                h=bridge_message.height,
                duration=bridge_message.duration,
            )
            event_id = await utils.send_video(self.mx, binding.room_id, media, text=text, html=False)

        elif media_kind in {"audio", "voice"}:
            media = Audio(
                url=media_bytes,
                caption=text,
                filename=filename,
                mimetype=mimetype,
                size=bridge_message.size,
                duration=bridge_message.duration,
            )
            event_id = await utils.send_audio(self.mx, binding.room_id, media, text=text, html=False)

        else:
            media = Document(
                url=media_bytes,
                caption=text,
                filename=filename,
                mimetype=mimetype,
                size=bridge_message.size,
            )
            event_id = await utils.send_document(self.mx, binding.room_id, media, text=text, html=False)

        return event_id

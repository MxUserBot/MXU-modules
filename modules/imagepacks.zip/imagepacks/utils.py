#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html


from mautrix.types import EventType

from mxc import utils


PACK_TYPE = EventType.find(utils.IMAGE_PACK_STABLE)

USAGE = """
• <code>.ipack create "Name" [--usage emoticon|sticker] [--attr "..."]</code>
• <code>.ipack add ["PackName"] :shortcode:</code> (reply to image)
• <code>.ipack remove "PackName" :shortcode:</code>
• <code>.ipack delete "PackName"</code>
• <code>.ipack list</code>
• <code>.ipack info ["PackName"]</code>
• <code>.ipack global</code>
• <code>.ipack global add</code> (reply to pack)
• <code>.ipack global remove "room_id" "state_key"</code>
• <code>.e :shortcode:</code> — send emote
• <code>.isticker "PackName" :shortcode:</code> — send sticker
"""

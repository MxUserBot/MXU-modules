#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

from mautrix.types import MessageEvent

from mxc import utils
from mxc.exceptions import UsageError
from mxc.types import Sticker, DownloadMeta
from ... import loader
from .models import IpAction
from .utils import PACK_TYPE, USAGE


@loader.tds
class ImagePackModule(loader.Module):
    strings = {
        "pack_created": "✅ <b>Pack created:</b> <code>{name}</code>",
        "image_added": "✅ <b>Added</b> <code>:{shortcode}:</code> to <b>{pack}</b>",
        "image_removed": "✅ <b>Removed</b> <code>:{shortcode}:</code> from <b>{pack}</b>",
        "pack_deleted": "✅ <b>Pack deleted:</b> <code>{name}</code>",
        "no_packs": "📭 <b>No image packs in this room.</b>",
        "no_images": "📭 <b>No images in this pack.</b>",
        "multiple_packs": "❌ <b>Multiple packs found.</b> Specify pack name.",
        "pack_not_found": "❌ <b>Pack not found:</b> <code>{name}</code>",
        "shortcode_invalid": "❌ <b>Invalid shortcode.</b>",
        "shortcode_exists": "❌ <b>Shortcode already exists:</b> <code>:{code}:</code>",
        "shortcode_not_found": "❌ <b>Shortcode not found:</b> <code>:{code}:</code>",
        "no_media": "❌ <b>Reply to an image/sticker.</b>",
        "no_reply": "❌ <b>Reply to a pack state event.</b>",
        "emoji_not_found": "❌ <b>Emote not found:</b> <code>:{code}:</code>",
        "not_in_pack": "❌ <b>No pack with that name.</b>",
        "global_added": "✅ <b>Pack globalised.</b>",
        "global_removed": "✅ <b>Pack removed from global.</b>",
        "global_list_empty": "📭 <b>No global packs.</b>",
    }

    @loader.command()
    async def ipack(self, mx, event: MessageEvent, action: IpAction = IpAction()):
        """create | add | remove | delete | list | info | global - Manage image packs (MSC2545)"""
        handler = {
            "create": self._create,
            "add": self._add,
            "remove": self._remove,
            "delete": self._delete,
            "list": self._list,
            "info": self._info,
            "global_list": self._global_list,
            "global_add": self._global_add,
            "global_remove": self._global_remove,
        }.get(action.action)

        if not handler:
            raise UsageError(USAGE)

        await handler(mx, event, action)

    async def _create(self, mx, event, action: IpAction):
        if not action.name:
            raise UsageError("Pack name required.")

        state_key = utils.sanitize_state_key(action.name)
        existing = await utils.get_room_packs(mx, event.room_id)

        if any(p["state_key"] == state_key for p in existing):
            raise UsageError(f"Pack '{action.name}' already exists.")

        if action.usage in (utils.USAGE_EMOTICON, utils.USAGE_STICKER):
            usage = [action.usage]
        else:
            usage = None

        content = utils.make_pack_content(
            display_name=action.name,
            usage=usage,
            attribution=action.attribution or None,
        )

        await mx.client.send_state_event(
            room_id=event.room_id,
            event_type=PACK_TYPE,
            state_key=state_key,
            content=content,
        )

        await utils.answer(mx, self.strings["pack_created"].format(name=action.name))

    async def _add(self, mx, event, action: IpAction):
        reply = await utils.get_reply_event(mx, event)
        if not reply:
            raise UsageError(self.strings["no_media"])

        mxc = await utils.download_and_upload_media(mx, reply)
        if not mxc:
            raise UsageError(self.strings["no_media"])

        if not action.shortcode or not utils.validate_shortcode(action.shortcode):
            raise UsageError(self.strings["shortcode_invalid"])

        packs = await utils.get_room_packs(mx, event.room_id)
        packs = [
            p for p in packs
            if utils.USAGE_STICKER not in p.get("usage", [])
            or not p.get("usage")
        ]

        if not packs:
            raise UsageError(self.strings["no_packs"])

        pack = self._resolve_pack(packs, action.name)

        state = await utils.fetch_pack_state(mx, event.room_id, pack["state_key"])
        images = state.get("images") or {}
        sc = action.shortcode

        if sc in images:
            raise UsageError(self.strings["shortcode_exists"].format(code=sc))

        body = getattr(reply.content, "body", None) or sc
        images[sc] = utils.make_image_object(url=mxc, body=body)
        state["images"] = images

        await mx.client.send_state_event(
            room_id=event.room_id,
            event_type=PACK_TYPE,
            state_key=pack["state_key"],
            content=state,
        )

        await utils.answer(
            mx,
            self.strings["image_added"].format(
                shortcode=sc,
                pack=pack.get("display_name", pack["state_key"]),
            ),
        )

    async def _remove(self, mx, event, action: IpAction):
        if not action.name or not action.shortcode:
            raise UsageError("Usage: <code>.ipack remove \"PackName\" :shortcode:</code>")

        pack = await utils.find_pack_by_name(mx, event.room_id, action.name)
        if not pack:
            raise UsageError(self.strings["pack_not_found"].format(name=action.name))

        state = await utils.fetch_pack_state(mx, event.room_id, pack["state_key"])
        images = state.get("images", {})
        sc = action.shortcode

        if sc not in images:
            raise UsageError(self.strings["shortcode_not_found"].format(code=sc))

        del images[sc]
        state["images"] = images

        await mx.client.send_state_event(
            room_id=event.room_id,
            event_type=PACK_TYPE,
            state_key=pack["state_key"],
            content=state,
        )

        await utils.answer(
            mx,
            self.strings["image_removed"].format(
                shortcode=sc,
                pack=pack.get("display_name", pack["state_key"]),
            ),
        )

    async def _delete(self, mx, event, action: IpAction):
        if not action.name:
            raise UsageError("Usage: <code>.ipack delete \"PackName\"</code>")

        pack = await utils.find_pack_by_name(mx, event.room_id, action.name)
        if not pack:
            raise UsageError(self.strings["pack_not_found"].format(name=action.name))

        await mx.client.send_state_event(
            room_id=event.room_id,
            event_type=PACK_TYPE,
            state_key=pack["state_key"],
            content={},
        )

        await utils.answer(
            mx,
            self.strings["pack_deleted"].format(
                name=pack.get("display_name", pack["state_key"]),
            ),
        )

    async def _list(self, mx, event, action: IpAction):
        packs = await utils.get_room_packs(mx, event.room_id)
        if not packs:
            raise UsageError(self.strings["no_packs"])

        lines = []
        for p in packs:
            display = p.get("display_name", p["state_key"])
            count = len(p.get("images", {}))
            emoji = utils.emoji_for_usage(p.get("usage", []))
            lines.append(f"• {emoji} <b>{display}</b> — <code>{count}</code> images")

        await utils.answer(mx, "📦 <b>Image packs:</b><br><br>" + "<br>".join(lines))

    async def _info(self, mx, event, action: IpAction):
        if action.name:
            pack = await utils.find_pack_by_name(mx, event.room_id, action.name)
        else:
            pack = None

        if not pack:
            packs = await utils.get_room_packs(mx, event.room_id)
            pack = packs[0] if packs else None

        if not pack:
            raise UsageError(self.strings["no_packs"])

        images = pack.get("images", {})
        if images:
            lines = []
            for code, img in sorted(images.items()):
                desc = (img.get("body") or "")[:40] or "no description"
                lines.append(f"• <code>:{code}:</code> — {desc}")
        else:
            lines = [self.strings["no_images"]]

        usage = ", ".join(pack.get("usage", [])) or "emoticon, sticker"
        header = (
            f"📦 <b>{pack.get('display_name', pack['state_key'])}</b><br>"
            f"Usage: <code>{usage}</code><br>"
            f"Images: <code>{len(images)}</code><br>"
        )

        if pack.get("attribution"):
            header += f"Attribution: <code>{pack['attribution']}</code><br>"

        await utils.answer(mx, header + "<br>" + "<br>".join(lines))

    async def _global_list(self, mx, event, action: IpAction):
        refs = await utils.get_global_pack_refs(mx)
        if not refs:
            raise UsageError(self.strings["global_list_empty"])

        lines = [
            f"• <code>{rid}</code> / <code>{sk}</code>"
            for rid, packs in refs.items()
            for sk in packs
        ]

        await utils.answer(mx, "🌍 <b>Global packs:</b><br><br>" + "<br>".join(lines))

    async def _global_add(self, mx, event, action: IpAction):
        reply = await utils.get_reply_event(mx, event)
        if not reply:
            raise UsageError(self.strings["no_reply"])

        eid = getattr(reply, "event_id", None)
        if not eid:
            raise UsageError(self.strings["no_reply"])

        state = await utils.get_state_event_by_id(mx, event.room_id, eid)
        if not state:
            raise UsageError(self.strings["no_reply"])

        sk = None
        packs = await utils.get_room_packs(mx, event.room_id)
        for p in packs:
            if p.get("event_id") == eid:
                sk = p["state_key"]
                break

        if not sk:
            sk = state.get("state_key")

        if not sk:
            raise UsageError("Could not determine pack state_key.")

        await utils.set_global_pack_ref(mx, event.room_id, sk, add=True)
        await utils.answer(mx, self.strings["global_added"])

    async def _global_remove(self, mx, event, action: IpAction):
        if not action.room_id or not action.state_key:
            raise UsageError('Usage: <code>.ipack global remove "room_id" "state_key"</code>')

        await utils.set_global_pack_ref(
            mx,
            action.room_id,
            action.state_key,
            add=False,
        )

        await utils.answer(mx, self.strings["global_removed"])

    def _resolve_pack(self, packs: list[dict], name: str) -> dict:
        if name:
            for p in packs:
                display = (p.get("display_name") or "").lower()
                state = (p.get("state_key") or "").lower()
                if name.lower() in (display, state):
                    return p

            raise UsageError(self.strings["not_in_pack"])

        if len(packs) == 1:
            return packs[0]

        raise UsageError(self.strings["multiple_packs"])

    @loader.command()
    async def e(self, mx, event: MessageEvent, shortcode: str = ""):
        """:shortcode: - Send an emote from any accessible pack"""
        if not shortcode:
            raise UsageError("Usage: <code>.e :shortcode:</code>")

        resolved = await utils.resolve_shortcode(mx, event.room_id, shortcode)
        if not resolved:
            code = utils.strip_shortcode(shortcode)
            raise UsageError(self.strings["emoji_not_found"].format(code=code))

        html = utils.make_emote_html(
            shortcode=resolved["shortcode"],
            mxc_url=resolved["mxc_url"],
            body=resolved.get("body"),
        )

        await utils.answer(mx, html, room_id=event.room_id)

    @loader.command()
    async def isticker(self, mx, event: MessageEvent, args: str = ""):
        """"PackName" :shortcode: - Send a sticker from a pack"""
        parts = utils.parse_quoted(args) or args.split()

        if len(parts) < 2:
            raise UsageError('Usage: <code>.isticker "PackName" :shortcode:</code>')

        pack = await utils.find_pack_by_name(mx, event.room_id, parts[0])
        if not pack:
            raise UsageError(self.strings["pack_not_found"].format(name=parts[0]))

        sc = utils.strip_shortcode(parts[1])
        images = pack.get("images", {})

        if sc not in images:
            raise UsageError(self.strings["shortcode_not_found"].format(code=sc))

        img = images[sc]

        try:
            data = await utils.download(mx, meta=DownloadMeta(url=img["url"]))
        except Exception:
            raise UsageError("Failed to download sticker media.")

        sticker = Sticker(
            url=data,
            mimetype=img.get("info", {}).get("mimetype", "image/png"),
            filename=f"{sc}.png",
        )

        await utils.answer(mx, media=sticker, room_id=event.room_id)

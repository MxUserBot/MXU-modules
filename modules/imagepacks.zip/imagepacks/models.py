#			__  ____  ___   _               _           _   
#			|  \/  \ \/ / | | |___  ___ _ __| |__   ___ | |_ 
#			| |\/| |\  /| | | / __|/ _ \ '__| '_ \ / _ \| __|
#			| |  | |/  \| |_| \__ \  __/ |  | |_) | (_) | |_ 
#			|_|  |_/_/\_\\___/|___/\___|_|  |_.__/ \___/ \__| 
#
# 🔒      Licensed under the GNU AGPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html


from typing import Any

from pydantic import BaseModel, ConfigDict, model_validator

from mxc import utils


class IpAction(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    action: str = "list"
    name: str = ""
    shortcode: str = ""
    usage: str = ""
    attribution: str = ""
    room_id: str = ""
    state_key: str = ""

    @model_validator(mode="before")
    @classmethod
    def parse(cls, v: Any):
        if not isinstance(v, str) or not v.strip():
            return {}

        parts = utils.parse_quoted(v) or v.strip().split()
        if not parts:
            return {}

        action = parts[0].lower()
        rest = parts[1:]

        if action == "create":
            return cls._parse_create(rest)

        if action in ("add", "remove"):
            return cls._parse_add_remove(action, rest)

        if action == "delete":
            return {"action": action, "name": rest[0] if rest else ""}

        if action == "info":
            return {"action": action, "name": rest[0] if rest else ""}

        if action == "global":
            return cls._parse_global(rest)

        return {"action": action}

    @classmethod
    def _parse_create(cls, rest: list[str]) -> dict:
        name = rest[0] if rest else ""
        usage = ""
        attr = ""

        i = 1
        while i < len(rest):
            if rest[i] == "--usage" and i + 1 < len(rest):
                usage = rest[i + 1]
                i += 2
            elif rest[i] == "--attr" and i + 1 < len(rest):
                attr = rest[i + 1]
                i += 2
            else:
                i += 1

        return {"action": "create", "name": name, "usage": usage, "attribution": attr}

    @classmethod
    def _parse_add_remove(cls, action: str, rest: list[str]) -> dict:
        name = ""
        shortcode = ""

        for p in rest:
            s = utils.strip_shortcode(p)
            if s and utils.validate_shortcode(s):
                shortcode = s
            else:
                name = p

        return {"action": action, "name": name, "shortcode": shortcode}

    @classmethod
    def _parse_global(cls, rest: list[str]) -> dict:
        sub = rest[0].lower() if rest else ""

        if sub == "add":
            return {"action": "global_add"}

        if sub == "remove" and len(rest) >= 3:
            return {
                "action": "global_remove",
                "room_id": rest[1],
                "state_key": rest[2],
            }

        return {"action": "global_list"}

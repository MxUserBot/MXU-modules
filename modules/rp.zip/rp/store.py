MANAGEMENT_CMDS = {"add", "new", "remove", "rm", "del", "delete", "list"}


class RolePlayStore:
    DEFAULT_ACTIONS = {
        "hug": {"verb": "hugged 🤗"},
        "slap": {"verb": "slapped 🖐️"},
        "kiss": {"verb": "kissed 💋"},
        "cuddle": {"verb": "cuddled 🥰"},
        "pat": {"verb": "patted 👋"},
        "poke": {"verb": "poked 👉"},
        "обнять": {"verb": "обнял 🤗"},
        "пинок": {"verb": "пнул 👞"},
        "поцеловать": {"verb": "поцеловал 💋"},
    }

    def __init__(self, get_fn, set_fn):
        self._get = get_fn
        self._set = set_fn

    async def load(self):
        actions = await self._get("actions", None)
        if actions is None:
            actions = dict(self.DEFAULT_ACTIONS)
            await self._set("actions", actions)
        return actions

    async def add(self, actions, name):
        name = name.lower().strip()
        if not name:
            return False, "empty_name"
        if name in actions:
            return False, "exists"
        if name in MANAGEMENT_CMDS:
            return False, "reserved"
        actions[name] = {"verb": name}
        await self._set("actions", actions)
        return True, "added"

    async def remove(self, actions, name):
        name = name.lower().strip()
        if name in self.DEFAULT_ACTIONS:
            return False, "default"
        if name not in actions:
            return False, "not_found"
        del actions[name]
        await self._set("actions", actions)
        return True, "removed"

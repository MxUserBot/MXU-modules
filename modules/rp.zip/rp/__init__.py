class Meta:
    name = "RolePlay"
    description = "RP actions via .rp"
    version = "3.0.0"
    tags = ["roleplay", "fun"]

from .main import RolePlayModule

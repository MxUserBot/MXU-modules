from ... import loader, utils as cutils
from mxc import utils
from .store import RolePlayStore


@loader.tds
class RolePlayModule(loader.Module):
    strings = {
        "action_msg": "<b><a href=\"https://matrix.to/#/{sender}\">{sender}</a></b> {verb} <a href=\"https://matrix.to/#/{target}\">{target}</a>",
        "need_target": "❌ Reply to someone or mention a user",
        "access_denied": "❌ You don't have access to this module",
        "add_access_denied": "❌ You don't have access to add RP commands",
        "exists": "❌ Action <code>{name}</code> already exists",
        "added": "✅ Action <code>{name}</code> added",
        "not_found": "❌ Action <code>{name}</code> not found",
        "removed": "✅ Action <code>{name}</code> removed",
        "cannot_remove_default": "❌ Cannot remove default action <code>{name}</code>",
        "list_title": "📋 <b>Available RP actions:</b>\n",
        "list_item": "• <code>{prefix}rp {name}</code>\n",
        "empty_name": "❌ Action name cannot be empty",
        "reserved": "❌ <code>{name}</code> is a reserved management command name",
        "no_such_action": "❌ Unknown action <code>{name}</code>",
        "usage": "❌ Usage:\n<code>{prefix}rp &lt;action&gt; [@user]</code>\n<code>{prefix}rp add &lt;action&gt;</code>\n<code>{prefix}rp remove &lt;action&gt;</code>\n<code>{prefix}rp list</code>",
    }

    config = {
        "access": loader.ConfigValue("all", "Who can use RP: all, sudo, owner, or comma-separated mxid list"),
        "add_access": loader.ConfigValue("all", "Who can add/remove RP commands: all, sudo, owner, or comma-separated mxid list"),
    }

    def __init__(self):
        self.store = None
        self._actions = {}

    async def _matrix_start(self, mx):
        self.store = RolePlayStore(self._get, self._set)
        self._actions = await self.store.load()

    async def _get_target(self, mx, event, args):
        reply = await utils.get_reply_event(mx, event)
        if reply:
            return reply.sender
        if args:
            return args.strip()
        return None

    def _has_access(self, mx, sender, access_type="access"):
        conf = self.config.get(access_type, "all").strip().lower()
        if conf == "all":
            return True
        if conf == "owner":
            return mx.security.is_owner(sender)
        if conf == "sudo":
            return sender in mx.security.sudos or mx.security.is_owner(sender)
        allowed = [x.strip() for x in conf.replace("\n", ",").split(",") if x.strip()]
        if sender in allowed:
            return True
        perms = mx.security.mod_perms.get(sender, [])
        if self.__class__.__name__.lower() in perms:
            return True
        return False

    @loader.command(aliases=["rp", "рп"], security=loader.ALL)
    async def rp(self, mx, event):
        """<action> [@user] / add / remove / list"""
        if not self._has_access(mx, event.sender, "access"):
            await utils.answer(mx, self.strings.get("access_denied"), event=event)
            return

        prefix = await utils.get_prefix(mx)
        raw = await cutils.get_args_raw(mx, event)

        if not raw:
            await utils.answer(mx, self.strings.get("usage").format(prefix=prefix), event=event)
            return

        parts = raw.split(maxsplit=2)
        subcmd = parts[0].lower().strip("\"'")

        if subcmd == "list":
            await self._cmd_list(mx, event, prefix)
        elif subcmd in ("add", "new"):
            await self._cmd_add(mx, event, parts)
        elif subcmd in ("remove", "rm", "del", "delete"):
            await self._cmd_remove(mx, event, parts)
        elif subcmd in self._actions:
            await self._exec_action(mx, event, subcmd, parts)
        else:
            await utils.answer(mx, self.strings.get("no_such_action").format(name=subcmd), event=event)

    async def _cmd_list(self, mx, event, prefix):
        text = self.strings.get("list_title")
        for name in self._actions:
            text += self.strings.get("list_item").format(prefix=prefix, name=name)
        await utils.answer(mx, text.strip(), event=event)

    async def _cmd_add(self, mx, event, parts):
        if not self._has_access(mx, event.sender, "add_access"):
            await utils.answer(mx, self.strings.get("add_access_denied"), event=event)
            return

        action_name = parts[1].strip().lower().strip("\"'") if len(parts) >= 2 else ""
        if not action_name:
            await utils.answer(mx, self.strings.get("empty_name"), event=event)
            return

        ok, key = await self.store.add(self._actions, action_name)
        await utils.answer(mx, self.strings.get(key).format(name=action_name), event=event)

    async def _cmd_remove(self, mx, event, parts):
        if not self._has_access(mx, event.sender, "add_access"):
            await utils.answer(mx, self.strings.get("add_access_denied"), event=event)
            return

        action_name = parts[1].strip().lower().strip("\"'") if len(parts) >= 2 else ""
        if not action_name:
            await utils.answer(mx, self.strings.get("empty_name"), event=event)
            return

        ok, key = await self.store.remove(self._actions, action_name)
        if not ok and key == "default":
            key = "cannot_remove_default"
        await utils.answer(mx, self.strings.get(key).format(name=action_name), event=event)

    async def _exec_action(self, mx, event, action_name, parts):
        action = self._actions[action_name]
        args = parts[1].strip() if len(parts) > 1 else ""

        target = await self._get_target(mx, event, args)
        if not target:
            await utils.answer(mx, self.strings.get("need_target"), event=event)
            return

        mentions = None
        if target.startswith("@") and ":" in target:
            mentions = {"user_ids": [target]}

        await utils.answer(
            mx,
            self.strings.get("action_msg").format(
                sender=event.sender, verb=action["verb"], target=target
            ),
            event=event,
            mentions=mentions,
        )
